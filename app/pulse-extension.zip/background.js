// Pulse LinkedIn Collector - Background Service Worker
// Runs the sync (both inboxes), reports rich progress to the popup, and
// auto-syncs daily via alarms.

const PULSE_API_URL = 'https://pulse.gershoncrm.com';
const EXT_VERSION = '1.20.0';

// ---------------------------------------------------------------------------
// AUTH — pulse.gershoncrm.com is behind a login. The extension has no cookie
// jar of its own, so it authenticates with a per-account collector token.
//
// v1.18.0: nobody types that token any more. When you open your Pulse dashboard
// signed in, the page reads your own token from /api/my-token and hands it to
// this worker over the content-script bridge (version-announce.js → SET_TOKEN).
// The manual paste box in the popup is only a fallback. The token lives in
// chrome.storage.local and is never in this source file — this extension ships
// from a PUBLIC repo.
// ---------------------------------------------------------------------------
const TOKEN_KEY = 'pulseToken';

async function getAuthToken() {
  try {
    const out = await chrome.storage.local.get(TOKEN_KEY);
    const t = out && out[TOKEN_KEY];
    return typeof t === 'string' && t.trim() ? t.trim() : null;
  } catch (e) {
    return null;
  }
}

// ---------------------------------------------------------------------------
// COLLECTING SESSION — is THIS computer allowed to collect?
//
// The same Pulse account is opened from several machines: one collects, the
// others only view. That choice belongs to the computer, so the dashboard keeps
// it in localStorage (`pulse_collecting`) and hands it to this worker over the
// content-script bridge (version-announce.js -> SET_COLLECTING). We mirror it
// into chrome.storage.local so a sync can be refused even when no Pulse tab is
// open.
//
// DEFAULT IS ON. A machine that has never opened the dashboard, or one on a
// dashboard older than v5.9.0, keeps collecting exactly as before — silence is
// never read as "stop collecting".
// ---------------------------------------------------------------------------
const COLLECTING_KEY = 'pulseCollecting';

async function isCollectingEnabled() {
  try {
    const out = await chrome.storage.local.get(COLLECTING_KEY);
    const v = out && out[COLLECTING_KEY];
    return v === false ? false : true;
  } catch (e) {
    return true; // never let a storage hiccup stop a collecting machine
  }
}

// Build the headers for an authenticated Pulse API call.
async function pulseHeaders() {
  const token = await getAuthToken();
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['X-Pulse-Token'] = token;
  return headers;
}

// Turn an auth failure into a message that says what to actually do about it,
// rather than a bare "401".
function authError(status) {
  if (status === 401 || status === 403) {
    return new Error('Pulse rejected the access token. Open pulse.gershoncrm.com while signed in — the extension reconnects itself.');
  }
  return null;
}

// Auto-sync alarm setup
const SYNC_ALARM_NAME = 'pulse-auto-sync';
const SYNC_INTERVAL_MINUTES = 24 * 60; // 24 hours

// The two inboxes we walk, in order.
// LinkedIn Messaging + Sales Navigator — the 10 most recent from each.
const SOURCES = [
  {
    name: 'linkedin-messaging',
    label: 'LinkedIn Messaging',
    url: 'https://www.linkedin.com/messaging/',
    match: 'https://www.linkedin.com/messaging/*',
  },
  {
    name: 'sales-navigator',
    label: 'Sales Navigator',
    url: 'https://www.linkedin.com/sales/inbox/',
    match: 'https://www.linkedin.com/sales/inbox/*',
  },
];

// ---------------------------------------------------------------------------
// Progress state — kept in memory during a run and mirrored to storage so a
// popup that opens (or re-opens) mid-sync can re-hydrate the bar + log.
// ---------------------------------------------------------------------------
let syncRunning = false;
let activeSource = null; // { name, label, index, of }
let syncState = freshState();

function freshState() {
  return {
    running: false,
    startedAt: null,
    finishedAt: null,
    // bar
    barValue: 0,
    barMax: 0,
    indeterminate: true,
    // headline
    statusText: 'Idle',
    stepText: '', // e.g. "Inbox 1 of 2 · LinkedIn Messaging"
    // rolling log of { key?, text, kind }
    log: [],
    // final outcome
    done: null, // { success, count }
  };
}

function persistState() {
  chrome.storage.local.set({ pulseSyncState: syncState });
}

// Apply an event to syncState (build log line + bar) then broadcast it.
function emit(evt) {
  evt.ts = new Date().toISOString();

  switch (evt.phase) {
    case 'start':
      syncState = freshState();
      syncState.running = true;
      syncState.startedAt = evt.ts;
      syncState.indeterminate = true;
      syncState.statusText = 'Starting sync…';
      appendLog(syncState, { text: '▶ Sync started — opening LinkedIn in the foreground.', kind: 'info' });
      break;

    case 'opening':
      syncState.indeterminate = true;
      syncState.barValue = 0;
      syncState.barMax = 0;
      syncState.stepText = `Inbox ${evt.index} of ${evt.of} · ${evt.sourceLabel}`;
      syncState.statusText = `Opening ${evt.sourceLabel}…`;
      appendLog(syncState, { text: `→ Opening ${evt.sourceLabel} (inbox ${evt.index} of ${evt.of})…`, kind: 'info' });
      break;

    case 'discovering':
      syncState.indeterminate = true;
      syncState.statusText = `Finding conversations in ${evt.sourceLabel}…`;
      appendLog(syncState, {
        key: `discover:${evt.source}`,
        text: `   Scanning ${evt.sourceLabel}: found ${evt.count} conversation${evt.count === 1 ? '' : 's'} so far…`,
        kind: 'muted',
      });
      break;

    case 'capturing':
      syncState.indeterminate = false;
      syncState.barValue = evt.count;
      syncState.barMax = evt.total || evt.count || 1;
      syncState.statusText = `Collecting ${evt.sourceLabel} — ${evt.count} of ${evt.total || '?'}`;
      appendLog(syncState, {
        key: `capture:${evt.source}`,
        text: `   Collecting ${evt.sourceLabel}: ${evt.count} of ${evt.total || '?'} conversations…`,
        kind: 'muted',
      });
      break;

    case 'source-done':
      syncState.indeterminate = false;
      if (evt.success) {
        appendLog(syncState, { text: `✓ ${evt.sourceLabel}: ${evt.count} conversation${evt.count === 1 ? '' : 's'} synced.`, kind: 'ok' });
      } else {
        appendLog(syncState, { text: `⚠ ${evt.sourceLabel}: ${evt.error || 'nothing collected'}.`, kind: 'warn' });
      }
      break;

    case 'posting':
      syncState.indeterminate = true;
      syncState.statusText = `Uploading ${evt.sourceLabel} to Pulse…`;
      appendLog(syncState, {
        key: `post:${evt.source}`,
        text: `   Uploading ${evt.sourceLabel} conversations to pulse.gershoncrm.com…`,
        kind: 'muted',
      });
      break;

    case 'enriching':
      syncState.indeterminate = !evt.total;
      syncState.barValue = evt.count || 0;
      syncState.barMax = evt.total || 1;
      syncState.statusText = `Reading profile locations — ${evt.count || 0} of ${evt.total || '?'}`;
      appendLog(syncState, {
        key: 'enrich',
        text: `   Reading profile locations… ${evt.count || 0} of ${evt.total || '?'}`,
        kind: 'muted',
      });
      break;

    case 'report':
      syncState.indeterminate = true;
      syncState.statusText = 'Sending email report…';
      appendLog(syncState, { text: '→ Triggering the email report…', kind: 'info' });
      break;

    case 'done':
      syncState.running = false;
      syncState.finishedAt = evt.ts;
      syncState.indeterminate = false;
      syncState.done = { success: evt.success, count: evt.count };
      if (evt.success) {
        syncState.barMax = syncState.barMax || 1;
        syncState.barValue = syncState.barMax;
        syncState.statusText = `Done — ${evt.count} conversation${evt.count === 1 ? '' : 's'} synced`;
        appendLog(syncState, { text: `✅ Done — ${evt.count} conversation${evt.count === 1 ? '' : 's'} synced to pulse.gershoncrm.com.`, kind: 'ok' });
      } else {
        syncState.statusText = 'Sync finished with errors';
        appendLog(syncState, { text: `❌ ${evt.error || 'Sync failed.'}`, kind: 'warn' });
      }
      break;

    case 'error':
      appendLog(syncState, { text: `⚠ ${evt.message}`, kind: 'warn' });
      break;
  }

  persistState();
  // Broadcast to any open popup. Wrapped in try/catch because there may be no receiver.
  chrome.runtime.sendMessage({ type: 'PULSE_PROGRESS', event: evt, state: syncState }).catch(() => {});
}

function appendLog(state, line) {
  if (line.key) {
    const existing = state.log.find((l) => l.key === line.key);
    if (existing) {
      existing.text = line.text;
      existing.kind = line.kind;
      return;
    }
  }
  state.log.push(line);
  // keep the log from growing without bound on very large inboxes
  if (state.log.length > 200) state.log.splice(0, state.log.length - 200);
}

// ---------------------------------------------------------------------------
// Alarms
// ---------------------------------------------------------------------------
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(SYNC_ALARM_NAME, {
    delayInMinutes: 1,
    periodInMinutes: SYNC_INTERVAL_MINUTES,
  });
  console.log('[Pulse] Auto-sync alarm set for every 24h');
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === SYNC_ALARM_NAME) {
    if (!(await isCollectingEnabled())) {
      console.log('[Pulse] Auto-sync skipped — Collecting Session is off on this computer');
      return;
    }
    console.log('[Pulse] Auto-sync triggered');
    await runFullSync({ auto: true });
  }
});

// ---------------------------------------------------------------------------
// The full sync — walk both inboxes, then trigger the report.
// ---------------------------------------------------------------------------
async function runFullSync({ auto } = {}) {
  if (syncRunning) return syncState.done || { success: false, error: 'A sync is already running.' };

  // This computer is a viewer: refuse before touching LinkedIn. We emit a real
  // start/done pair (rather than returning silently) so the dashboard's progress
  // poller shows the reason instead of a badge stuck on "Starting…".
  if (!(await isCollectingEnabled())) {
    const offMsg = 'Collecting Session is off on this computer. Turn it on in Pulse → Settings → This computer to sync from here.';
    emit({ phase: 'start', auto: !!auto });
    emit({ phase: 'done', success: false, count: 0, error: offMsg });
    return { success: false, error: offMsg, collectingOff: true };
  }

  // Fail fast and loudly if the extension has never been given a token — far
  // better than walking both inboxes for two minutes and then being rejected.
  if (!(await getAuthToken())) {
    return {
      success: false,
      error: 'No Pulse access token. Open the extension popup and paste the token from Cloudflare (EXTENSION_TOKEN).',
    };
  }

  syncRunning = true;

  emit({ phase: 'start', auto: !!auto });

  const results = {};
  let totalPosted = 0;

  try {
    for (let i = 0; i < SOURCES.length; i++) {
      const src = SOURCES[i];
      activeSource = { name: src.name, label: src.label, index: i + 1, of: SOURCES.length };
      const r = await syncSource(src, i + 1, SOURCES.length);
      results[src.name] = r;
      if (r.success) totalPosted += r.count || 0;
      emit({
        phase: 'source-done',
        source: src.name,
        sourceLabel: src.label,
        success: r.success,
        count: r.count || 0,
        error: r.error,
      });
    }

    emit({ phase: 'report' });
    await triggerEmailReport();

    const anySuccess = Object.values(results).some((r) => r && r.success);
    const done = { success: anySuccess, count: totalPosted, results };
    emit({ phase: 'done', success: anySuccess, count: totalPosted, error: anySuccess ? null : 'No conversations collected. Keep the LinkedIn inbox tab visible during the sync.' });

    chrome.storage.local.set({
      lastSync: new Date().toISOString(),
      lastSyncResults: results,
    });
    return done;
  } catch (err) {
    emit({ phase: 'done', success: false, count: totalPosted, error: err.message });
    return { success: false, error: err.message };
  } finally {
    syncRunning = false;
    activeSource = null;
  }
}

async function syncSource(src, index, of) {
  emit({ phase: 'opening', source: src.name, sourceLabel: src.label, index, of });

  // Find or create the inbox tab. LinkedIn will NOT render the conversation
  // list in a hidden/background tab, so it must be visible + focused.
  const tabs = await chrome.tabs.query({ url: src.match });
  let tab;
  const createdTab = tabs.length === 0;
  if (tabs.length > 0) {
    tab = tabs[0];
    await chrome.tabs.update(tab.id, { url: src.url, active: true });
  } else {
    tab = await chrome.tabs.create({ url: src.url, active: true });
  }
  try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (e) {}

  await waitForTab(tab.id);

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (e) {
    // already injected
  }

  await new Promise((r) => setTimeout(r, 2000));

  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tab.id, { type: 'START_COLLECTION' }, async (response) => {
      if (chrome.runtime.lastError || !response || !response.success) {
        resolve({ success: false, count: 0, error: chrome.runtime.lastError?.message || 'No response from the page' });
        return;
      }

      const convs = response.conversations || [];
      // 0 conversations means the inbox did not render — do not overwrite good data.
      if (convs.length === 0) {
        resolve({ success: false, count: 0, error: 'Collected 0 — keep the inbox tab visible during the sync.' });
        return;
      }

      try {
        // POST FIRST so the data lands on the dashboard immediately — before the
        // slower, best-effort location enrichment runs.
        emit({ phase: 'posting', source: src.name, sourceLabel: src.label });
        const first = await postConversations(convs, src, response.meta);

        // Then enrich city/country from each profile and re-post (upsert by name).
        // Only for smaller runs — opening a profile tab per person is too slow
        // for large collections (100 would open 100 tabs). Large runs keep the
        // exact links + grade and skip location.
        if (src.name === 'linkedin-messaging' && convs.length <= 15) {
          await enrichLocations(convs, src.label);
          try { await postConversations(convs, src, Object.assign({}, response.meta || {}, { enrichment: true })); } catch (e) {}
        }

        resolve({ success: true, count: convs.length, apiResult: first });
      } catch (err) {
        resolve({ success: false, count: convs.length, error: err.message });
      } finally {
        if (createdTab) chrome.tabs.remove(tab.id).catch(() => {});
      }
    });
  });
}

// POST conversations to the Pulse API (upsert by name).
async function postConversations(convs, src, meta) {
  const res = await fetch(`${PULSE_API_URL}/api/messages`, {
    method: 'POST',
    headers: await pulseHeaders(),
    body: JSON.stringify({
      conversations: convs,
      // v1.20.0 — `complete` + `verified` let the server mirror the inbox (drop
      // conversations that are gone) only after a full, verified crawl.
      scanMeta: Object.assign({ source: src.name, version: EXT_VERSION }, meta ? {
        complete: !!meta.complete && !meta.enrichment,
        verified: meta.verified || 0,
        skipped: meta.skipped || 0,
        skippedNames: (meta.skippedNames || []).slice(0, 30),
        owner: meta.owner || '',
      } : {}),
    }),
  });
  const authFail = authError(res.status);
  if (authFail) throw authFail;
  const out = await res.json().catch(() => ({}));
  // v1.20.0 — surface a refused sync (e.g. 426 "update required") instead of reporting success.
  if (!res.ok) throw new Error((out && out.error) || ('Pulse API error ' + res.status));
  return out;
}

// Enrich conversations with city/country read from each partner's profile.
async function enrichLocations(convs, sourceLabel) {
  const targets = convs.filter((c) => c.profileUrl && /\/in\//.test(c.profileUrl));
  let done = 0;
  emit({ phase: 'enriching', sourceLabel, count: 0, total: targets.length });
  for (const c of targets) {
    try {
      const loc = await readProfileLocation(c.profileUrl);
      if (loc) {
        const parts = loc.split(',').map((s) => s.trim()).filter(Boolean);
        if (parts.length === 1) { c.country = parts[0]; }
        else if (parts.length > 1) { c.city = parts[0]; c.country = parts[parts.length - 1]; }
        c.locationRaw = loc;
      }
    } catch (e) { /* best effort */ }
    done++;
    emit({ phase: 'enriching', sourceLabel, count: done, total: targets.length, name: c.name });
  }
}

// Open a profile in a background tab, read its top-card location, close it.
function readProfileLocation(profileUrl) {
  return new Promise(async (resolve) => {
    let tab = null;
    const timer = setTimeout(() => { if (tab) chrome.tabs.remove(tab.id).catch(() => {}); resolve(''); }, 18000);
    try {
      tab = await chrome.tabs.create({ url: profileUrl, active: false });
      await waitForTab(tab.id);
      await new Promise((r) => setTimeout(r, 2500));
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const lines = (((document.querySelector('main') || document.body).innerText) || '')
            .split('\n').map((s) => s.trim()).filter(Boolean);
          const ci = lines.indexOf('Contact info');
          let loc = '';
          if (ci > 0) {
            for (let k = ci - 1; k >= Math.max(0, ci - 4); k--) {
              if (lines[k] && lines[k] !== '·') { loc = lines[k]; break; }
            }
          }
          return loc;
        },
      });
      clearTimeout(timer);
      chrome.tabs.remove(tab.id).catch(() => {});
      resolve((results && results[0] && results[0].result) || '');
    } catch (e) {
      clearTimeout(timer);
      if (tab) chrome.tabs.remove(tab.id).catch(() => {});
      resolve('');
    }
  });
}

function waitForTab(tabId) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    }, 30000);

    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(resolve, 3000);
      }
    }

    chrome.tabs.onUpdated.addListener(listener);
    chrome.tabs.get(tabId, (tab) => {
      if (tab && tab.status === 'complete') {
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(listener);
        setTimeout(resolve, 3000);
      }
    });
  });
}

async function triggerEmailReport() {
  try {
    const res = await fetch(`${PULSE_API_URL}/api/report`, {
      method: 'POST',
      headers: await pulseHeaders(),
      body: JSON.stringify({ trigger: 'sync' }),
    });
    const authFail = authError(res.status);
    if (authFail) throw authFail;
    return await res.json();
  } catch (err) {
    console.error('[Pulse] Email report trigger failed:', err);
    return { success: false, error: err.message };
  }
}

// ---------------------------------------------------------------------------
// Messages from popup + content script
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Does the extension have an access token yet? The popup asks on open so it
  // knows whether to show the one-time setup screen or the Sync Now button.
  if (message.type === 'GET_TOKEN_STATUS') {
    getAuthToken().then((t) => sendResponse({ hasToken: !!t }));
    return true;
  }

  // Save (or replace) the access token, then verify it against the server so a
  // bad value is caught here instead of halfway through a sync. Sent either by
  // the dashboard (automatic, via the bridge) or by the popup's manual fallback.
  if (message.type === 'SET_TOKEN') {
    const token = String(message.token || '').trim();
    if (!token) {
      sendResponse({ success: false, error: 'Paste the token first.' });
      return true;
    }
    fetch(`${PULSE_API_URL}/api/auth/session`, {
      method: 'GET',
      headers: { 'X-Pulse-Token': token },
    })
      .then((res) => {
        if (res.status === 401 || res.status === 403) {
          return { success: false, error: 'Pulse rejected that token. Open pulse.gershoncrm.com while signed in and let it reconnect the extension.' };
        }
        if (!res.ok) {
          return { success: false, error: `Pulse returned ${res.status}. Try again in a moment.` };
        }
        return chrome.storage.local.set({ [TOKEN_KEY]: token }).then(() => ({ success: true }));
      })
      .catch((err) => ({ success: false, error: `Could not reach pulse.gershoncrm.com (${err.message}).` }))
      .then(sendResponse);
    return true;
  }

  // The dashboard tells us whether THIS computer collects. Sent on every Pulse
  // page load and the moment the radio is flipped in Settings.
  if (message.type === 'SET_COLLECTING') {
    const on = message.collecting !== false;
    chrome.storage.local
      .set({ [COLLECTING_KEY]: on })
      .then(() => sendResponse({ success: true, collecting: on }))
      .catch((e) => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (message.type === 'GET_COLLECTING') {
    isCollectingEnabled().then((on) => sendResponse({ collecting: on }));
    return true;
  }

  if (message.type === 'CLEAR_TOKEN') {
    chrome.storage.local.remove(TOKEN_KEY).then(() => sendResponse({ success: true }));
    return true;
  }

  // The popup clicked "Sync Now".
  if (message.type === 'SYNC_NOW') {
    if (syncRunning) {
      // Already running — just let the popup re-hydrate from state.
      sendResponse({ success: true, alreadyRunning: true, state: syncState });
      return true;
    }
    runFullSync({ auto: false }).then((done) => {
      try { sendResponse(done); } catch (e) {}
    });
    return true; // keep channel open (may take minutes)
  }

  // The popup opened and wants the current state to render.
  if (message.type === 'GET_SYNC_STATE') {
    sendResponse({ running: syncRunning, state: syncState });
    return true;
  }

  // Progress relayed from the content script during scroll/capture.
  if (message.type === 'SCAN_PROGRESS') {
    const src = activeSource || { name: 'linkedin-messaging', label: 'LinkedIn Messaging' };
    if (message.phase === 'capturing-links') {
      emit({ phase: 'capturing', source: src.name, sourceLabel: src.label, count: message.count, total: message.total });
    } else {
      emit({ phase: 'discovering', source: src.name, sourceLabel: src.label, count: message.count });
    }
    return; // no response needed
  }

  // Manual trigger kept for compatibility.
  if (message.type === 'FORCE_AUTO_SYNC') {
    runFullSync({ auto: false }).then(() => sendResponse({ success: true }));
    return true;
  }
});

console.log(`[Pulse] Background service worker loaded (v${EXT_VERSION})`);
