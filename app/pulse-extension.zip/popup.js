// Pulse LinkedIn Collector - Popup Script
// Single "Sync Now" action. Shows a live progress bar + log while the
// background service worker walks both inboxes. Re-hydrates from stored
// state if the popup is closed and re-opened mid-sync.

const btn = document.getElementById('btn-sync');
const panel = document.getElementById('panel');
const stepEl = document.getElementById('step');
const statusEl = document.getElementById('status');
const barTrack = document.getElementById('bar-track');
const barFill = document.getElementById('bar-fill');
const barCount = document.getElementById('bar-count');
const logEl = document.getElementById('log');
const statusArea = document.getElementById('status-area');

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function showStatus(message, isError) {
  statusArea.innerHTML = `<div class="status-msg ${isError ? 'status-error' : 'status-success'}">${escapeHtml(message)}</div>`;
}

// Render the whole progress panel from a state object.
function render(state) {
  if (!state) return;
  panel.classList.add('active');

  stepEl.textContent = state.stepText || '';
  statusEl.textContent = state.statusText || '';

  if (state.indeterminate) {
    barTrack.classList.add('indeterminate');
    barCount.textContent = '';
  } else {
    barTrack.classList.remove('indeterminate');
    const max = state.barMax || 0;
    const val = Math.min(state.barValue || 0, max || Infinity);
    const pct = max > 0 ? Math.round((val / max) * 100) : 0;
    barFill.style.width = pct + '%';
    barCount.textContent = max > 0 ? `${val} / ${max}` : '';
  }

  // Log
  logEl.innerHTML = (state.log || [])
    .map((l) => `<div class="log-line ${l.kind || ''}">${escapeHtml(l.text)}</div>`)
    .join('');
  logEl.scrollTop = logEl.scrollHeight;

  // Button + final banner
  if (state.running) {
    btn.disabled = true;
    btn.textContent = 'Syncing…';
    statusArea.innerHTML = '';
  } else {
    btn.disabled = false;
    btn.textContent = 'Sync Now';
    if (state.done) {
      if (state.done.success) {
        showStatus(`Done — ${state.done.count} conversations synced to pulse.gershoncrm.com`, false);
      } else {
        showStatus('Sync finished with errors — see the log above.', true);
      }
    }
  }
}

// On open: ask the background for the current state and render it.
chrome.runtime.sendMessage({ type: 'GET_SYNC_STATE' }, (resp) => {
  if (chrome.runtime.lastError) return;
  if (resp && resp.state && (resp.running || (resp.state.log && resp.state.log.length))) {
    render(resp.state);
  }
});

// Start a sync.
btn.addEventListener('click', () => {
  statusArea.innerHTML = '';
  panel.classList.add('active');
  logEl.innerHTML = '';
  stepEl.textContent = '';
  statusEl.textContent = 'Starting…';
  barTrack.classList.add('indeterminate');
  barCount.textContent = '';
  btn.disabled = true;
  btn.textContent = 'Syncing…';

  chrome.runtime.sendMessage({ type: 'SYNC_NOW' }, (result) => {
    // May fire minutes later, or not at all if the popup was closed. Live
    // updates come via PULSE_PROGRESS below; this is just a fallback.
    if (chrome.runtime.lastError) return;
    if (result && result.state) render(result.state);
  });
});

// Live progress from the background service worker.
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'PULSE_PROGRESS' && message.state) {
    render(message.state);
  }
});
