// Pulse LinkedIn Collector - Popup Script
// Single "Sync Now" action. Shows a live progress bar + log while the
// background service worker walks both inboxes. Re-hydrates from stored
// state if the popup is closed and re-opened mid-sync.
//
// v1.16.0: pulse.gershoncrm.com is behind a login, so the collector needs an
// access token.
// v1.18.0: it no longer asks anyone to type one. The signed-in dashboard hands
// the token over automatically (see version-announce.js → setToken), so this
// screen just points at Pulse and waits. Manual paste stays as a fallback.

const btn = document.getElementById('btn-sync');
const setupEl = document.getElementById('setup');
const mainEl = document.getElementById('main');
const tokenInput = document.getElementById('token-input');
const openPulseBtn = document.getElementById('btn-open-pulse');
const manualToggle = document.getElementById('btn-manual');
const manualEl = document.getElementById('manual');
const saveTokenBtn = document.getElementById('btn-save-token');
const setupStatus = document.getElementById('setup-status');
const changeTokenBtn = document.getElementById('btn-change-token');
const panel = document.getElementById('panel');
const stepEl = document.getElementById('step');
const statusEl = document.getElementById('status');
const barTrack = document.getElementById('bar-track');
const barFill = document.getElementById('bar-fill');
const barCount = document.getElementById('bar-count');
const logEl = document.getElementById('log');
const statusArea = document.getElementById('status-area');

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function showStatus(message, isError) {
  statusArea.innerHTML = `<div class="status-msg ${isError ? 'status-error' : 'status-success'}">${escapeHtml(message)}</div>`;
}

// Render the whole progress panel from a state object.
function render(state) {
  if (!state) return;
  panel.classList.add('active');

  stepEl.textContent = state.stepText || '';
  statusEl.textContent = state.statusText || '';

  if (state.indeterminate) {
    barTrack.classList.add('indeterminate');
    barCount.textContent = '';
  } else {
    barTrack.classList.remove('indeterminate');
    const max = state.barMax || 0;
    const val = Math.min(state.barValue || 0, max || Infinity);
    const pct = max > 0 ? Math.round((val / max) * 100) : 0;
    barFill.style.width = pct + '%';
    barCount.textContent = max > 0 ? `${val} / ${max}` : '';
  }

  // Log
  logEl.innerHTML = (state.log || [])
    .map((l) => `<div class="log-line ${l.kind || ''}">${escapeHtml(l.text)}</div>`)
    .join('');
  logEl.scrollTop = logEl.scrollHeight;

  // Button + final banner
  if (state.running) {
    btn.disabled = true;
    btn.textContent = 'Syncing…';
    statusArea.innerHTML = '';
  } else {
    btn.disabled = false;
    btn.textContent = 'Sync Now';
    if (state.done) {
      if (state.done.success) {
        showStatus(`Done — ${state.done.count} conversations synced to pulse.gershoncrm.com`, false);
      } else {
        showStatus('Sync finished with errors — see the log above.', true);
      }
    }
  }
}

// ─── ACCESS TOKEN ───

function showSetup(message) {
  setupEl.classList.add('active');
  mainEl.classList.remove('active');
  setupStatus.innerHTML = message
    ? `<div class="status-msg status-error">${escapeHtml(message)}</div>`
    : '';
}

function showMain() {
  setupEl.classList.remove('active');
  mainEl.classList.add('active');
  setupStatus.innerHTML = '';
  tokenInput.value = '';
}

// Decide which screen to show before anything else renders.
chrome.runtime.sendMessage({ type: 'GET_TOKEN_STATUS' }, (resp) => {
  if (chrome.runtime.lastError) { showMain(); return; }
  if (resp && resp.hasToken) showMain(); else showSetup('');
});

const PULSE_URL = 'https://pulse.gershoncrm.com/app.html';

// "Open Pulse and connect" — the dashboard's Extension page does the handshake
// the moment it loads, so all the user has to do is be signed in.
openPulseBtn.addEventListener('click', () => {
  chrome.tabs.create({ url: PULSE_URL });
  window.close();
});

manualToggle.addEventListener('click', () => {
  manualEl.classList.add('active');
  manualToggle.style.display = 'none';
  tokenInput.focus();
});

// If the dashboard connects us while this popup happens to be open (a detached
// window, or a second monitor), swap to the Sync screen without a click.
let watchTimer = setInterval(() => {
  if (!setupEl.classList.contains('active')) return;
  chrome.runtime.sendMessage({ type: 'GET_TOKEN_STATUS' }, (resp) => {
    if (chrome.runtime.lastError) return;
    if (resp && resp.hasToken) {
      clearInterval(watchTimer);
      showMain();
      showStatus('Connected to Pulse. You can sync now.', false);
    }
  });
}, 1500);
window.addEventListener('pagehide', () => clearInterval(watchTimer));

function saveToken() {
  const token = tokenInput.value.trim();
  if (!token) { showSetup('Paste the access token first.'); manualEl.classList.add('active'); return; }

  saveTokenBtn.disabled = true;
  saveTokenBtn.textContent = 'Checking…';
  setupStatus.innerHTML = '';

  chrome.runtime.sendMessage({ type: 'SET_TOKEN', token }, (resp) => {
    saveTokenBtn.disabled = false;
    saveTokenBtn.textContent = 'Connect';
    if (chrome.runtime.lastError) { showSetup('Extension error — reload it and try again.'); return; }
    if (resp && resp.success) {
      showMain();
      showStatus('Connected to Pulse. You can sync now.', false);
    } else {
      showSetup((resp && resp.error) || 'Could not save the token.');
      manualEl.classList.add('active');
      manualToggle.style.display = 'none';
    }
  });
}

saveTokenBtn.addEventListener('click', saveToken);
tokenInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') saveToken(); });

changeTokenBtn.addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'CLEAR_TOKEN' }, () => showSetup(''));
});

// On open: ask the background for the current state and render it.
chrome.runtime.sendMessage({ type: 'GET_SYNC_STATE' }, (resp) => {
  if (chrome.runtime.lastError) return;
  if (resp && resp.state && (resp.running || (resp.state.log && resp.state.log.length))) {
    render(resp.state);
  }
});

// Start a sync.
btn.addEventListener('click', () => {
  statusArea.innerHTML = '';
  panel.classList.add('active');
  logEl.innerHTML = '';
  stepEl.textContent = '';
  statusEl.textContent = 'Starting…';
  barTrack.classList.add('indeterminate');
  barCount.textContent = '';
  btn.disabled = true;
  btn.textContent = 'Syncing…';

  chrome.runtime.sendMessage({ type: 'SYNC_NOW' }, (result) => {
    // May fire minutes later, or not at all if the popup was closed. Live
    // updates come via PULSE_PROGRESS below; this is just a fallback.
    if (chrome.runtime.lastError) return;
    if (result && result.state) { render(result.state); return; }
    // No state came back — the sync was refused before it started (usually a
    // missing or rejected token). Say so instead of leaving a dead spinner.
    if (result && result.success === false) {
      btn.disabled = false;
      btn.textContent = 'Sync Now';
      panel.classList.remove('active');
      showStatus(result.error || 'Sync could not start.', true);
      if (/token/i.test(result.error || '')) showSetup(result.error);
    }
  });
});

// Live progress from the background service worker.
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'PULSE_PROGRESS' && message.state) {
    render(message.state);
  }
});
