// Announces the installed Pulse extension version to the Pulse web app, so the
// dashboard can show a red warning when the installed version is out of date.
(function () {
  try {
    var v = chrome.runtime.getManifest().version;
    document.documentElement.setAttribute('data-pulse-ext-version', v);
    window.dispatchEvent(new CustomEvent('pulse-ext-version', { detail: { version: v } }));
  } catch (e) {}
})();
