// version-announce.js — Pulse page ⇄ extension bridge  (extension v1.18.0)
//
// Runs as a content script on https://pulse.gershoncrm.com/*. Two jobs:
//
//   1. ANNOUNCE — publish the installed extension version to the dashboard, so
//      the Extension page can say "installed / out of date / not detected".
//      (This half existed before v1.17; the attribute + event names are
//      unchanged so older dashboards keep working.)
//
//   2. BRIDGE — relay a tiny, fixed set of requests from the page to the
//      background service worker, so the dashboard's Extension page can run
//      its self-test and start a real sync without opening the popup.
//
// SECURITY: a web page can never touch chrome.* directly. Everything goes
// through the window.postMessage protocol below, and this script only honours
// messages that came from THIS window at THIS origin, with the exact envelope
// shape. The action list is a closed allowlist — the page cannot name an
// arbitrary background message type.
//
// Protocol (page → bridge):   { __pulse: 'req', id, action, payload }
//          (bridge → page):   { __pulse: 'res', id, ok, data, error }
//          (bridge → page):   { __pulse: 'progress', data: { running, state } }
//
// Actions: ping | tokenStatus | setToken | clearToken | syncState | syncNow
//
// v1.18.0 adds setToken/clearToken, which is what removes the old "paste the
// token from Cloudflare" screen: the dashboard reads the signed-in user's own
// collector token from /api/my-token (session-only) and hands it straight to
// the background worker. The user installs the extension and it is connected.
//
// Why this is safe: the page half of this handshake is same-origin
// pulse.gershoncrm.com, and the ONLY way that page can obtain a token is with a
// valid session cookie for the account the token belongs to. A hostile site
// cannot reach this listener at all (origin check below), and a signed-in user
// handing themselves their own token grants nothing they did not already have.
(function () {
  var BRIDGE_PROTOCOL = 2;   // 2 = setToken/clearToken available
  var ORIGIN = window.location.origin;
  var POLL_MS = 1000;
  var pollTimer = null;
  var idleTicks = 0;

  function extVersion() {
    try {
      return chrome.runtime.getManifest().version;
    } catch (e) {
      return null; // extension context invalidated (e.g. just reloaded)
    }
  }

  // ── 1. Announce ───────────────────────────────────────────────────────────
  function announce() {
    var v = extVersion();
    var root = document.documentElement;
    // documentElement can still be null if this ever runs at document_start.
    if (!v || !root) return;
    root.setAttribute('data-pulse-ext-version', v);
    root.setAttribute('data-pulse-ext-bridge', String(BRIDGE_PROTOCOL));
    try {
      window.dispatchEvent(
        new CustomEvent('pulse-ext-version', { detail: { version: v, bridge: BRIDGE_PROTOCOL } })
      );
    } catch (e) {}
  }

  // The dashboard boots its own scripts after document_idle, so re-announce a
  // couple of times — cheap, and it removes a whole class of "not detected"
  // false negatives caused by pure timing. Wrapped so a failure here can never
  // stop the bridge listener below from being registered.
  try {
    announce();
    window.addEventListener('load', announce);
    setTimeout(announce, 1200);
    setTimeout(announce, 3000);
  } catch (e) {}

  // ── 2. Bridge ─────────────────────────────────────────────────────────────

  // Promise wrapper around chrome.runtime.sendMessage. Rejects (instead of
  // silently resolving undefined) when the service worker is unreachable or
  // the extension was reloaded out from under this content script.
  function ask(type, extra) {
    return new Promise(function (resolve, reject) {
      var payload = { type: type };
      if (extra) {
        for (var k in extra) {
          if (Object.prototype.hasOwnProperty.call(extra, k)) payload[k] = extra[k];
        }
      }
      try {
        chrome.runtime.sendMessage(payload, function (resp) {
          var err = chrome.runtime.lastError;
          if (err) {
            reject(new Error(err.message || 'The extension did not respond.'));
            return;
          }
          resolve(resp);
        });
      } catch (e) {
        reject(new Error('Extension context invalidated — reload this page.'));
      }
    });
  }

  function reply(id, ok, data, error) {
    if (!id) return;
    try {
      window.postMessage({ __pulse: 'res', id: id, ok: !!ok, data: data || null, error: error || null }, ORIGIN);
    } catch (e) {}
  }

  function pushProgress(data) {
    try {
      window.postMessage({ __pulse: 'progress', data: data }, ORIGIN);
    } catch (e) {}
  }

  // While a sync runs, poll the background for state and stream it to the page.
  // Polling (rather than pushing from background.js) keeps the change surface
  // to this one file: chrome.runtime.sendMessage from the worker does not reach
  // content scripts anyway, so a push would need tab bookkeeping there.
  function startPolling() {
    if (pollTimer) return;
    idleTicks = 0;
    pollTimer = setInterval(function () {
      ask('GET_SYNC_STATE')
        .then(function (resp) {
          if (!resp) return;
          pushProgress(resp);
          if (resp.running) {
            idleTicks = 0;
          } else if (++idleTicks >= 2) {
            // Two consecutive idle reads: the run is over (the second read
            // guarantees the page received the final state, log and all).
            stopPolling();
          }
        })
        .catch(function () {
          stopPolling();
        });
    }, POLL_MS);
  }

  function stopPolling() {
    if (pollTimer) {
      clearInterval(pollTimer);
      pollTimer = null;
    }
  }

  var ACTIONS = {
    // "Are you there, and which version?" — also re-announces, so a page that
    // loaded before this script can recover without a refresh.
    ping: function () {
      announce();
      var v = extVersion();
      if (!v) return Promise.reject(new Error('Extension context invalidated — reload this page.'));
      return Promise.resolve({ version: v, bridge: BRIDGE_PROTOCOL });
    },

    // Does the collector hold an API token? (Never returns the token itself.)
    tokenStatus: function () {
      return ask('GET_TOKEN_STATUS').then(function (r) {
        return { hasToken: !!(r && r.hasToken) };
      });
    },

    // Hand the collector its API token. The dashboard calls this automatically
    // on load when the collector has no token yet, and again right after a
    // rotation, so nobody ever copies a token by hand.
    //
    // The background worker verifies the token against /api/auth/session before
    // storing it, so a stale or wrong value is rejected here rather than halfway
    // through a sync.
    setToken: function (payload) {
      var token = payload && typeof payload.token === 'string' ? payload.token.trim() : '';
      if (!token) return Promise.reject(new Error('No token supplied.'));
      return ask('SET_TOKEN', { token: token }).then(function (r) {
        if (r && r.success) return { saved: true };
        throw new Error((r && r.error) || 'Pulse would not accept that token.');
      });
    },

    // Forget the stored token — used by "Disconnect" on the Extension page.
    clearToken: function () {
      return ask('CLEAR_TOKEN').then(function () {
        return { cleared: true };
      });
    },

    // Current progress snapshot — used to re-hydrate the page mid-sync.
    syncState: function () {
      return ask('GET_SYNC_STATE').then(function (r) {
        if (r && r.running) startPolling();
        return { running: !!(r && r.running), state: (r && r.state) || null };
      });
    },

    // Start a sync. The background keeps its response channel open for the
    // whole run (minutes), so we deliberately do NOT wait for it: we answer the
    // page immediately and stream progress via the poller instead.
    syncNow: function () {
      return ask('GET_SYNC_STATE').then(function (current) {
        if (current && current.running) {
          startPolling();
          return { started: false, alreadyRunning: true, state: current.state || null };
        }
        try {
          chrome.runtime.sendMessage({ type: 'SYNC_NOW' }, function () {
            // Fires when the whole run finishes (or never, if the worker was
            // recycled). Swallow lastError; the poller is the source of truth.
            void chrome.runtime.lastError;
          });
        } catch (e) {
          return Promise.reject(new Error('Extension context invalidated — reload this page.'));
        }
        startPolling();
        return { started: true, alreadyRunning: false };
      });
    },
  };

  window.addEventListener('message', function (event) {
    // Only this window, only this origin, only our envelope.
    if (event.source !== window) return;
    if (event.origin !== ORIGIN) return;
    var msg = event.data;
    if (!msg || msg.__pulse !== 'req' || typeof msg.action !== 'string') return;

    var handler = Object.prototype.hasOwnProperty.call(ACTIONS, msg.action) ? ACTIONS[msg.action] : null;
    if (!handler) {
      reply(msg.id, false, null, 'Unknown action: ' + msg.action);
      return;
    }

    Promise.resolve()
      .then(function () {
        return handler(msg.payload);
      })
      .then(function (data) {
        reply(msg.id, true, data, null);
      })
      .catch(function (err) {
        reply(msg.id, false, null, (err && err.message) || 'Extension error');
      });
  });

  // Don't leave a timer running against a torn-down page.
  window.addEventListener('pagehide', stopPolling);
})();
