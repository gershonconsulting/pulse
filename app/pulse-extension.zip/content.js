// Pulse LinkedIn Collector - Content Script
// Runs on LinkedIn messaging pages and Sales Navigator inbox to extract conversation data

(function () {
  "use strict";

  const SCROLL_DELAY = 1500;
  const MAX_SCROLL_ATTEMPTS = 50;
  const CAMPAIGN_PATTERN = /\b(BD\d+)\b/i; // Matches campaign codes like BD18, BD20

  // Detect page type
  const isSalesNavigator = location.pathname.startsWith('/sales/inbox');

  // Classification rules
  function classify(conversation) {
    const { lastSender, snippet } = conversation;
    const lower = snippet.toLowerCase();

    // GREEN: You (Olivier) sent the last message
    if (lastSender === "you") {
      return { status: "Green", reason: "You sent the last message" };
    }

    // Check for ORANGE patterns (no action needed)
    const declinePatterns = [
      /non\s*(merci|pas)/i,
      /not\s*interested/i,
      /no\s*thank/i,
      /already\s*(have|present|exist)/i,
      /d[eé]j[aà]/i,
      /pas\s*(du\s*tout|besoin|int[eé]ress)/i,
      /belle\s*soir[eé]e/i,
      /bonne\s*(journ[eé]e|continuation)/i,
      /merci\s*(je\s*regarde|pour)/i,
      /i('|\s)ll\s*(look|check|get\s*back)/i,
      /we('|\s)re\s*(good|all\s*set|covered)/i,
      /no\s*need/i,
      /freelance.*seul/i,
    ];

    for (const pattern of declinePatterns) {
      if (pattern.test(lower)) {
        return { status: "Orange", reason: "Decline or acknowledgment detected" };
      }
    }

    // RED: Question, interest, action needed
    const redPatterns = [
      /\?/,
      /drop\s*(me|us)\s*(an?\s*)?email/i,
      /let('|\s)s\s*(connect|chat|talk|meet|schedule|arrange)/i,
      /interested/i,
      /i('|\s)d\s*(love|like)\s*to/i,
      /can\s*(we|you)/i,
      /would\s*(love|like|value)/i,
      /reach(ing)?\s*out/i,
      /open\s*to/i,
      /working\s*on\s*something/i,
      /your\s*perspective/i,
      /how\s*to/i,
      /tell\s*me\s*more/i,
      /send\s*(me|us)/i,
      /waiting/i,
      /follow\s*up/i,
      /thank\s*you\s*for\s*reach/i,
      /great\s*to\s*reconnect/i,
      /investor/i,
      /syndicate/i,
      /attachment/i,
    ];

    for (const pattern of redPatterns) {
      if (pattern.test(lower)) {
        return { status: "Red", reason: "Interest, question, or action needed" };
      }
    }

    // Default: if they sent last and no pattern matched, mark Red (safe side)
    if (lastSender !== "you") {
      return { status: "Red", reason: "They sent last - review needed" };
    }

    return { status: "Green", reason: "No action detected" };
  }

  // Extract data from a single LinkedIn Messaging conversation list item
  function extractConversation(item) {
    const lines = item.innerText.split("\n").filter((l) => l.trim());

    // Find name (skip status lines, timestamps, notifications)
    let name = "";
    for (const line of lines) {
      if (
        line.startsWith("Status is") ||
        line.match(/^\d+:\d+/) ||
        line.match(/^May|^Apr|^Mar|^Feb|^Jan|^Jun|^Jul|^Aug|^Sep|^Oct|^Nov|^Dec/) ||
        line.includes("new notification") ||
        line.includes("Press return") ||
        line.includes("Open the options") ||
        line.includes("Active conversation") ||
        line.includes("Star conversation") ||
        line.includes("Select conversation") ||
        line.includes("Received") ||
        line.includes("Sponsored") ||
        line.length <= 2
      ) {
        continue;
      }
      name = line.trim();
      break;
    }

    // Find snippet (message preview)
    let snippet = "";
    let lastSender = "them";
    for (const line of lines) {
      if (line.startsWith("You:")) {
        snippet = line.substring(4).trim();
        lastSender = "you";
        break;
      }
      const nameFirst = name.split(" ")[0];
      if (line.startsWith(nameFirst + ":")) {
        snippet = line.substring(nameFirst.length + 1).trim();
        lastSender = "them";
        break;
      }
    }

    // Find date
    let date = "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.match(/^\d+:\d+\s*(AM|PM)$/i)) {
        date = trimmed;
        break;
      }
      if (trimmed.match(/^(May|Apr|Mar|Feb|Jan|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d+$/)) {
        date = trimmed;
        break;
      }
    }

    // Unread count
    let unread = 0;
    const unreadEl = item.querySelector('[class*="unread-count"]');
    if (unreadEl) {
      unread = parseInt(unreadEl.innerText) || 0;
    }

    // LinkedIn profile URL
    let profileUrl = "";
    const profileLink = item.querySelector('a[href*="/in/"]');
    if (profileLink) {
      profileUrl = profileLink.href;
    }

    // Thread ID from conversation link — try multiple strategies
    let threadId = "";
    let conversationLink = "";

    // Strategy 1: The main conversation link element (most reliable)
    const mainLink = item.querySelector('a.msg-conversation-listitem__link') ||
                     item.querySelector('a[href*="/messaging/thread/"]') ||
                     item.querySelector('a[data-control-name="view_message"]');
    if (mainLink) {
      const href = mainLink.getAttribute("href") || "";
      const threadMatch = href.match(/\/messaging\/thread\/([^/?]+)/);
      if (threadMatch) {
        threadId = threadMatch[1];
        conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
      }
    }

    // Strategy 2: Any <a> inside the list item with a thread path
    if (!threadId) {
      const allLinks = item.querySelectorAll('a[href]');
      for (const link of allLinks) {
        const href = link.getAttribute("href") || "";
        const threadMatch = href.match(/\/messaging\/thread\/([^/?]+)/);
        if (threadMatch) {
          threadId = threadMatch[1];
          conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
          break;
        }
      }
    }

    // Strategy 3: data attributes on the item or its children
    if (!threadId) {
      const dataId = item.getAttribute("data-thread-id") ||
                     item.querySelector('[data-thread-id]')?.getAttribute("data-thread-id") ||
                     item.getAttribute("data-thread-urn") ||
                     item.querySelector('[data-thread-urn]')?.getAttribute("data-thread-urn") || "";
      if (dataId) {
        threadId = dataId.replace(/^urn:li:messagingThread:/, '');
        conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
      }
    }

    // Strategy 4: Extract from the item's id attribute (LinkedIn uses URN-based IDs)
    if (!threadId) {
      const itemId = item.getAttribute("id") || "";
      const idMatch = itemId.match(/thread[_-]?(.+)/i);
      if (idMatch) {
        threadId = idMatch[1];
        conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
      }
    }

    // Strategy 5: Click the item to trigger navigation, read the URL from the panel
    // (done passively — if conversation is already selected, grab from current URL)
    if (!threadId && window.location.href.includes('/messaging/thread/')) {
      // Check if this conversation is the currently active one
      const isActive = item.classList.contains('active') ||
                       item.querySelector('.msg-conversation-listitem__link--active');
      if (isActive) {
        const urlMatch = window.location.href.match(/\/messaging\/thread\/([^/?]+)/);
        if (urlMatch) {
          threadId = urlMatch[1];
          conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
        }
      }
    }

    // Last resort: use searchString (unreliable but better than nothing)
    if (!conversationLink && name) {
      conversationLink = "https://www.linkedin.com/messaging/?searchString=" + encodeURIComponent(name);
    }

    // Extract campaign code from snippet or full text
    let campaign = null;
    const allText = lines.join(" ");
    const campMatch = allText.match(CAMPAIGN_PATTERN);
    if (campMatch) {
      campaign = campMatch[1].toUpperCase();
    }
    // Also check snippet specifically
    if (!campaign && snippet) {
      const snippetMatch = snippet.match(CAMPAIGN_PATTERN);
      if (snippetMatch) campaign = snippetMatch[1].toUpperCase();
    }

    if (!name || name.includes("Sponsored")) return null;

    const conv = { name, snippet, lastSender, date, unread, profileUrl };
    const classification = classify(conv);

    return {
      ...conv,
      status: classification.status,
      reason: classification.reason,
      threadId,
      conversationLink,
      campaign,
      source: "linkedin-messaging",
      collectedAt: new Date().toISOString(),
    };
  }

  // Extract data from a single Sales Navigator inbox conversation list item
  function extractSNConversation(item) {
    const lines = item.innerText.split("\n").filter((l) => l.trim());

    // Sales Navigator structure: [Name, Snippet, Date]
    let name = "";
    let snippet = "";
    let date = "";

    if (lines.length >= 1) {
      name = lines[0].trim();
    }
    if (lines.length >= 2) {
      snippet = lines[1].trim();
    }
    if (lines.length >= 3) {
      date = lines[2].trim();
    }

    if (!name) return null;

    // Determine lastSender:
    // In SN there's no "You:" prefix. Detect if you sent last by checking
    // if snippet starts with greeting patterns (= you initiated/replied last)
    let lastSender = "them";
    const youSentPatterns = [
      /^Bonjour\s/i,
      /^Hi\s/i,
      /^Hello\s/i,
      /^Hey\s/i,
      /^Dear\s/i,
      /^Cher\s/i,
      /^Ch[eè]re\s/i,
      /^Bonsoir\s/i,
    ];
    for (const pattern of youSentPatterns) {
      if (pattern.test(snippet)) {
        lastSender = "you";
        break;
      }
    }

    // Thread ID from data attribute
    let threadId = "";
    const dataAttr = item.getAttribute("data-x-conversation-list-item") || "";
    if (dataAttr) {
      threadId = dataAttr;
    }

    // Conversation link from the item's link element
    let conversationLink = "";
    const linkEl = item.querySelector('.conversation-list-item__link');
    if (linkEl) {
      const href = linkEl.getAttribute("href") || "";
      const snMatch = href.match(/\/sales\/inbox\/([^/?]+)/);
      if (snMatch) {
        threadId = threadId || snMatch[1];
        conversationLink = "https://www.linkedin.com/sales/inbox/" + (threadId || snMatch[1]);
      }
    }
    if (!conversationLink && threadId) {
      conversationLink = "https://www.linkedin.com/sales/inbox/" + threadId;
    }

    // No profile links available in SN list items
    const profileUrl = "";

    // No unread badge elements found in SN
    const unread = 0;

    // Extract campaign code from snippet or full text
    let campaign = null;
    const allText = lines.join(" ");
    const campMatch = allText.match(CAMPAIGN_PATTERN);
    if (campMatch) {
      campaign = campMatch[1].toUpperCase();
    }
    if (!campaign && snippet) {
      const snippetMatch = snippet.match(CAMPAIGN_PATTERN);
      if (snippetMatch) campaign = snippetMatch[1].toUpperCase();
    }

    const conv = { name, snippet, lastSender, date, unread, profileUrl };
    const classification = classify(conv);

    return {
      ...conv,
      status: classification.status,
      reason: classification.reason,
      threadId,
      conversationLink,
      campaign,
      source: "sales-navigator",
      collectedAt: new Date().toISOString(),
    };
  }

  // Scroll the LinkedIn Messaging conversation list to load all items
  async function scrollConversationList() {
    const listEl = document.querySelector(".msg-conversations-container__conversations-list");
    if (!listEl) {
      console.log("[Pulse] Conversation list not found");
      return;
    }

    let previousCount = 0;
    let attempts = 0;

    while (attempts < MAX_SCROLL_ATTEMPTS) {
      const items = document.querySelectorAll("li.msg-conversation-listitem");
      const currentCount = items.length;

      if (currentCount === previousCount && attempts > 2) {
        // Try clicking "Load more" button
        const loadMore = document.querySelector(
          'button[aria-label*="Load more"], button:has(> span:contains("Load more"))'
        );
        if (loadMore) {
          loadMore.click();
          await sleep(2000);
        } else {
          // Also try finding by text content
          const buttons = document.querySelectorAll("button");
          let found = false;
          for (const btn of buttons) {
            if (btn.innerText.includes("Load more conversations")) {
              btn.click();
              found = true;
              await sleep(2000);
              break;
            }
          }
          if (!found) {
            console.log(`[Pulse] No more conversations to load. Total: ${currentCount}`);
            break;
          }
        }
      }

      previousCount = currentCount;

      // Scroll the conversation list container
      const scrollContainer =
        listEl.closest(".msg-conversations-container__conversations-list") ||
        listEl.parentElement;
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
      // Also scroll the list itself
      listEl.scrollTop = listEl.scrollHeight;

      attempts++;
      await sleep(SCROLL_DELAY);

      // Update progress via message to popup
      chrome.runtime.sendMessage({
        type: "SCAN_PROGRESS",
        count: currentCount,
        attempt: attempts,
      });
    }
  }

  // Scroll the Sales Navigator inbox list to load all items
  async function scrollSNConversationList() {
    // Find the scrollable container for SN inbox
    const listItems = document.querySelectorAll('.conversation-list-item');
    if (!listItems.length) {
      console.log("[Pulse] Sales Navigator conversation list not found");
      return;
    }

    // Find the scroll container (parent of the list items)
    const scrollContainer = listItems[0].closest('[class*="conversation-list"]') ||
                            listItems[0].parentElement;
    if (!scrollContainer) {
      console.log("[Pulse] Sales Navigator scroll container not found");
      return;
    }

    let previousCount = 0;
    let attempts = 0;

    while (attempts < MAX_SCROLL_ATTEMPTS) {
      const items = document.querySelectorAll('.conversation-list-item');
      const currentCount = items.length;

      if (currentCount === previousCount && attempts > 2) {
        console.log(`[Pulse] No more SN conversations to load. Total: ${currentCount}`);
        break;
      }

      previousCount = currentCount;

      // Scroll the container
      scrollContainer.scrollTop = scrollContainer.scrollHeight;

      attempts++;
      await sleep(SCROLL_DELAY);

      // Update progress via message to popup
      chrome.runtime.sendMessage({
        type: "SCAN_PROGRESS",
        count: currentCount,
        attempt: attempts,
      });
    }
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Language detection (lightweight heuristic; user can correct on the dashboard).
  function detectLang(t) {
    t = (t || "").toLowerCase();
    const fr = (t.match(/\b(bonjour|merci|vous|votre|nous|je|suis|être|avec|pour|bonne|journée|entreprise|société|très|aussi|besoin|intéress|rendez|discuter|salut|cordialement)\b/g) || []).length;
    const en = (t.match(/\b(hi|hello|the|you|your|we|our|thanks|thank|would|could|please|team|company|interested|meeting|reach|best|regards)\b/g) || []).length;
    if (fr > en && fr >= 2) return "French";
    if (en >= 2) return "English";
    return fr > en ? "French" : "English";
  }

  // A reply that means "no action needed now" — an explicit decline, OR an
  // out-of-office / deferral ("taking time off", "get back to you later").
  const DECLINE_OR_DEFER = /pas int[ée]ress|aucun besoin|ne m.int[ée]resse|not interested|no need|no thank|d[ée]clin|unsubscribe|time off|out of office|on vacation|on holiday|on leave|\bo\.?o\.?o\b|limited (internet|connectivity|access)|get back to you|at a later time|circle back|reconnect later|currently (traveling|travelling|away)|en cong[ée]|en vacances|absent|je reviens vers vous/i;

  // ── v1.20.0 (2026-10-28) — VERIFIED capture ────────────────────────────────
  // Before 1.20.0 the collector read the NAME from the list row, clicked, slept a
  // fixed 1.6 s and then read whatever the pane showed. When LinkedIn was slow the
  // pane still showed the PREVIOUS conversation, so one person's thread was stored
  // under another person's name (found on Anne Bougel's account 2026-10-28:
  // "Mélanie St-Martin" holding "Hi Jacqui…", "Jacqui" holding "Hi Pablo…", …).
  // Now every capture waits until the pane really belongs to the clicked row
  // (URL thread changed + header name == row name + message list changed), takes
  // the name FROM THE OPENED THREAD, and a capture that cannot be verified is
  // SKIPPED rather than stored wrong.
  const PRESENCE_RE = /\s+(is online|is reachable|was (last )?active.*|status is .*|active now.*|est en ligne|en ligne)$/i;
  function cleanName(s) {
    return String(s || "").split("\n")[0].replace(PRESENCE_RE, "").replace(/\s+/g, " ").replace(/,\s*$/, "").trim();
  }
  function normName(s) {
    return cleanName(s).normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
  }
  function ownerFromPage() {
    const img = document.querySelector(".global-nav__me-photo, img.global-nav__me-photo, .global-nav__primary-link-me-menu-trigger img");
    const alt = img && (img.getAttribute("alt") || "").replace(/^photo of\s+/i, "").replace(/^photo de\s+/i, "");
    return cleanName(alt || "");
  }
  function liSignature() {
    const evs = document.querySelectorAll(".msg-s-event-listitem");
    const last = evs[evs.length - 1];
    return evs.length + "|" + (last ? last.innerText.slice(0, 120) : "");
  }
  // v1.21.0 — CONTENT check. v1.20.0 verified the URL and the header name but not the
  // MESSAGES: LinkedIn swaps the header first and the message list later, so a thread
  // was still stored with another conversation's last message (found 2026-11-02 on
  // every tenant: "Sanjay Hari" holding "Hi Scott…", "Vinay" holding "Hi Sanjay…").
  // The list row's own preview ("You: …" / "Sam: …") belongs to that row for sure, so
  // the pane's last message must start with it before anything is captured.
  function squash(s) {
    return String(s || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "");
  }
  const NON_TEXT_PREVIEW = /(sent (an? )?(attachment|post|photo|image|video|voice|gif|link|message)|a envoy|inmail|sponsored|reacted|a reagi|shared a|a partag)/i;
  function liRowPreview(item) {
    const el = item.querySelector(".msg-conversation-card__message-snippet, .msg-conversation-listitem__message-snippet");
    let t = el ? el.innerText.trim() : "";
    t = t.replace(/^[^:\n]{1,60}:\s*/, ""); // "You: " / "Sam: "
    if (!t || NON_TEXT_PREVIEW.test(t)) return "";
    return squash(t).slice(0, 24);
  }
  function liLastBody() {
    const evs = document.querySelectorAll(".msg-s-event-listitem");
    for (let k = evs.length - 1; k >= 0; k--) {
      const b = (evs[k].querySelector(".msg-s-event-listitem__body") || {}).innerText;
      if (b && b.trim()) return b.trim();
    }
    return "";
  }
  function previewMatches(preview, body) {
    if (!preview) return true;
    const b = squash(body);
    return b.startsWith(preview) || b.indexOf(preview) !== -1;
  }
  // "Hi Scott," sent by the owner in a thread whose header is someone else = crossed.
  const GREET_RE = /^(?:hi|hello|hey|dear|bonjour|salut|hola|hallo|ciao)\s+([A-Za-zÀ-ÿ'-]{2,})/i;
  function greetingMismatch(body, header) {
    const g = String(body || "").match(GREET_RE);
    if (!g) return false;
    const x = normName(g[1]);
    if (["all", "there", "everyone", "again", "team", "tous", "vous", "toi"].includes(x)) return false;
    const parts = normName(header).split(/[^a-z'-]+/).filter(Boolean);
    return !parts.some((p) => p === x || (p.length > 2 && (p.startsWith(x) || x.startsWith(p))));
  }

  async function waitForLiPane(want, prevThread, prevSig, preview) {
    const t0 = Date.now();
    let headerOkAt = 0;
    while (Date.now() - t0 < 9000) {
      await sleep(150);
      const m = location.href.match(/\/messaging\/thread\/([^/?]+)/);
      const thread = m ? m[1] : null;
      const hdr = cleanName((document.querySelector("h2.msg-entity-lockup__entity-title") || {}).innerText || "");
      const headerOk = thread && thread !== prevThread && normName(hdr) === normName(want);
      if (!headerOk) { headerOkAt = 0; continue; }
      if (!headerOkAt) headerOkAt = Date.now();
      const sig = liSignature();
      const hasMsgs = document.querySelectorAll(".msg-s-event-listitem").length > 0;
      // v1.21.0: the messages must have swapped in AND the last one must be the row's
      // preview. No more "header right for 2.5 s → capture anyway" fallback.
      const contentOk = hasMsgs && (preview ? previewMatches(preview, liLastBody()) : (sig !== prevSig && Date.now() - headerOkAt > 1200));
      if (contentOk) {
        await sleep(400); // let the last bubbles finish rendering
        if (liSignature() !== sig) continue; // still rendering — re-check
        if (preview && !previewMatches(preview, liLastBody())) continue;
        return { thread, header: hdr };
      }
    }
    return null;
  }

  async function collectAllConversations() {
    const LIMIT = 100;
    const meta = { verified: 0, skipped: 0, skippedNames: [], complete: false, owner: "" };
    console.log("[Pulse] Collecting up to " + LIMIT + " recent LinkedIn conversations (verified capture)...");

    let waited = 0;
    while (document.querySelectorAll("li.msg-conversation-listitem").length === 0 && waited < 36) {
      await sleep(500);
      waited++;
    }
    await sleep(1000);

    const ownerName = ownerFromPage();
    meta.owner = ownerName;
    const listEl = document.querySelector(".msg-conversations-container__conversations-list");

    const conversations = [];
    const seenThreads = new Set();
    let stagnant = 0;

    while (conversations.length < LIMIT && stagnant < 6) {
      const fresh = Array.from(document.querySelectorAll("li.msg-conversation-listitem:not([data-pulse-done])"));
      if (fresh.length === 0) {
        if (listEl) listEl.scrollTop = listEl.scrollHeight;
        await sleep(1500);
        stagnant++;
        continue;
      }
      stagnant = 0;

      for (const item of fresh) {
        if (conversations.length >= LIMIT) break;
        item.setAttribute("data-pulse-done", "1");
        const nameEl = item.querySelector(".msg-conversation-listitem__participant-names, h3");
        const want = cleanName(nameEl ? nameEl.innerText : "");
        if (!want || /sponsored/i.test(item.innerText.slice(0, 200))) continue;
        const timeEl = item.querySelector("time, .msg-conversation-listitem__time-stamp");
        const listDate = timeEl ? timeEl.innerText.trim() : "";
        const unread = item.querySelector(".msg-conversation-card__unread-count") ? 1 : 0;

        const preview = liRowPreview(item);
        const clickable = item.querySelector(".msg-conversation-listitem__link") || item.querySelector('[role="link"]') || item;
        let pane = null;
        for (let attempt = 0; attempt < 2 && !pane; attempt++) {
          const pm = location.href.match(/\/messaging\/thread\/([^/?]+)/);
          const prevThread = pm ? pm[1] : null;
          const prevSig = liSignature();
          try {
            clickable.scrollIntoView({ block: "center" });
            await sleep(200);
            clickable.click();
            pane = await waitForLiPane(want, prevThread, prevSig, preview);
          } catch (e) { pane = null; }
        }
        if (!pane) {
          meta.skipped++;
          if (meta.skippedNames.length < 30) meta.skippedNames.push(want);
          console.log("[Pulse] SKIPPED (pane never matched): " + want);
          continue;
        }
        if (seenThreads.has(pane.thread)) continue;
        seenThreads.add(pane.thread);

        const data = { name: pane.header || want, date: listDate, unread };
        data.threadId = pane.thread;
        data.conversationLink = "https://www.linkedin.com/messaging/thread/" + pane.thread + "/";

        const primary = document.querySelector(".msg-thread__link-to-profile");
        const primaryHref = primary ? (primary.getAttribute("href") || "").split("?")[0] : "";
        // v1.21.0: keep the profile link only if it is labelled with THIS person's name.
        const primaryLabel = primary ? ((primary.getAttribute("title") || "") + " " + primary.innerText) : "";
        const primaryOk = primaryHref && normName(primaryLabel).indexOf(normName(data.name)) !== -1;
        if (primaryOk) data.profileUrl = primaryHref.startsWith("http") ? primaryHref : "https://www.linkedin.com" + primaryHref;

        // Authors per message group; the LAST named group is the last sender.
        const groupNames = Array.from(document.querySelectorAll(".msg-s-message-group__name"))
          .map((e) => cleanName(e.innerText)).filter(Boolean);
        const evs = Array.from(document.querySelectorAll(".msg-s-event-listitem"));
        let lastAuthor = groupNames.length ? groupNames[groupNames.length - 1] : null;
        if (!lastAuthor) {
          for (let k = evs.length - 1; k >= 0; k--) {
            const n = evs[k].querySelector('[class*="__name"]');
            if (n && n.innerText.trim()) { lastAuthor = cleanName(n.innerText); break; }
          }
        }
        const isGroup = / and you$|, .+ and /i.test(want) || new Set(groupNames.filter((g) => normName(g) !== normName(ownerName))).size > 1;
        data.isGroup = isGroup;
        // 1:1 sanity check — every author must be the owner or the person in the header.
        if (!isGroup && ownerName) {
          const stranger = groupNames.find((g) => normName(g) !== normName(ownerName) && normName(g) !== normName(data.name));
          if (stranger) {
            meta.skipped++;
            if (meta.skippedNames.length < 30) meta.skippedNames.push(want + " (author " + stranger + ")");
            continue;
          }
        }

        const allText = evs.map((e) => (e.querySelector(".msg-s-event-listitem__body") || {}).innerText || "").join(" ");
        let lastBody = "";
        for (let k = evs.length - 1; k >= 0; k--) {
          const b = (evs[k].querySelector(".msg-s-event-listitem__body") || {}).innerText;
          if (b && b.trim()) { lastBody = b.trim(); break; }
        }
        if (lastBody) data.snippet = lastBody.slice(0, 300);
        if (!ownerName || !lastAuthor) data.lastSender = "unknown";
        else data.lastSender = normName(lastAuthor) === normName(ownerName) ? "you" : "them";
        // Only the OWNER's own greeting names the counterpart ("Hi Scott," in Sanjay's thread = crossed).
        if (!isGroup && data.lastSender === "you" && greetingMismatch(lastBody, data.name)) {
          meta.skipped++;
          if (meta.skippedNames.length < 30) meta.skippedNames.push(want + " (greeting mismatch)");
          continue;
        }
        data.language = detectLang(allText || lastBody);

        const low = (lastBody || "").toLowerCase();
        if (data.lastSender === "you") {
          data.status = "Green"; data.reason = "You sent the last message"; data.ball = "their turn";
        } else if (DECLINE_OR_DEFER.test(low)) {
          data.status = "Orange"; data.reason = "Decline / out-of-office / deferral"; data.ball = "closed";
        } else {
          data.status = "Red"; data.reason = data.lastSender === "unknown" ? "Sender could not be read — check" : "They replied — your turn"; data.ball = "your turn";
        }
        data.verified = true;
        data.country = "";
        data.city = "";
        data.platform = "linkedin";
        data.source = "linkedin-messaging";
        data.collectedAt = new Date().toISOString();
        if (data.date) data.timestamp = data.date;
        meta.verified++;
        conversations.push(data);

        chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", count: conversations.length, total: LIMIT, phase: "capturing-links" });
      }

      if (listEl) listEl.scrollTop = listEl.scrollHeight;
      await sleep(1200);
    }

    meta.complete = conversations.length >= LIMIT || stagnant >= 6;
    console.log("[Pulse] Collected " + conversations.length + " LinkedIn conversations (" + meta.skipped + " skipped)");
    return { conversations, meta };
  }

  function scrollableAncestor(el) {
    let n = el ? el.parentElement : null;
    while (n && n !== document.body) {
      const st = getComputedStyle(n);
      if (/(auto|scroll)/.test(st.overflowY) && n.scrollHeight > n.clientHeight) return n;
      n = n.parentElement;
    }
    return null;
  }
  function snPaneName() {
    const a = Array.from(document.querySelectorAll('a[href*="/sales/lead/"]')).find((x) => !x.closest(".conversation-list-item") && x.innerText.trim());
    return a ? cleanName(a.innerText) : "";
  }
  function snSignature() {
    const arts = Array.from(document.querySelectorAll("article")).filter((a) => !/Message thread list/i.test(a.innerText));
    const last = arts[arts.length - 1];
    return arts.length + "|" + (last ? last.innerText.slice(0, 120) : "");
  }

  // Main collection function — Sales Navigator (verified capture, v1.21.0)
  async function collectAllSNConversations() {
    console.log("[Pulse] Starting Sales Navigator conversation collection (verified capture)...");
    const LIMIT = 100;
    const meta = { verified: 0, skipped: 0, skippedNames: [], complete: false };
    let wSN = 0;
    while (document.querySelectorAll(".conversation-list-item").length === 0 && wSN < 36) { await sleep(500); wSN++; }
    await sleep(1000);

    // The REAL scroller (before 1.20.0 the wrong element was scrolled, so only the
    // first ~19 rows were ever read and a different 19 piled up every day).
    const scrollC = scrollableAncestor(document.querySelector(".conversation-list-item"));

    const conversations = [];
    const seen = new Set();
    let stagnant = 0;

    while (conversations.length < LIMIT && stagnant < 6) {
      const fresh = Array.from(document.querySelectorAll(".conversation-list-item:not([data-pulse-done])"));
      if (fresh.length === 0) {
        if (scrollC) scrollC.scrollTop = scrollC.scrollHeight;
        await sleep(1800);
        stagnant++;
        continue;
      }
      stagnant = 0;

      for (const item of fresh) {
        if (conversations.length >= LIMIT) break;
        item.setAttribute("data-pulse-done", "1");
        const lines0 = item.innerText.trim().split("\n").map((s) => s.trim()).filter(Boolean);
        // Line 0 is often "<Name> was last active 2 hours ago" / "<Name> is online".
        let want = cleanName(lines0[0] || "");
        if (lines0[1] && PRESENCE_RE.test(lines0[0]) && cleanName(lines0[1])) want = cleanName(lines0[1]);
        if (!want) continue;
        const listTime = lines0.find((l) => /\d{1,2}:\d{2}\s*(AM|PM)?/i.test(l) && l.length < 12 || /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun|lun|mar|mer|jeu|ven|sam|dim)\.?$/i.test(l) || /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(l)) || "";

        const tA = item.querySelector('a[href*="/sales/inbox/"]');
        const rowLink = tA ? ("https://www.linkedin.com" + tA.getAttribute("href").split("?")[0]) : null;
        const rowThread = rowLink ? (rowLink.match(/\/sales\/inbox\/([^/?]+)/) || [])[1] : null;
        if (rowLink && seen.has(rowLink)) continue;

        // v1.21.0: the row's preview text must appear in the pane's last message.
        const snPreview = (() => {
          const cand = lines0.slice(1).filter((l) => l.length >= 12 && !PRESENCE_RE.test(" " + l) && l !== listTime && normName(l) !== normName(want));
          let t = cand.length ? cand[cand.length - 1] : "";
          t = t.replace(/^(You|Vous)\s*:\s*/i, "").replace(/^[^:]{1,40}:\s*/, "");
          return NON_TEXT_PREVIEW.test(t) ? "" : squash(t).slice(0, 20);
        })();
        const snLastArticle = () => {
          const arts = Array.from(document.querySelectorAll("article")).filter((a) => !a.closest(".conversation-list-item"));
          return arts.length ? arts[arts.length - 1].innerText : "";
        };
        let ok = false;
        for (let attempt = 0; attempt < 2 && !ok; attempt++) {
          const prevSig = snSignature();
          try {
            (tA || item).click();
            const t0 = Date.now();
            let nameOkAt = 0;
            while (Date.now() - t0 < 10000) {
              await sleep(200);
              const urlOk = !rowThread || location.href.indexOf(rowThread) !== -1;
              const nameOk = normName(snPaneName()) === normName(want);
              if (!(urlOk && nameOk)) { nameOkAt = 0; continue; }
              if (!nameOkAt) nameOkAt = Date.now();
              const contentOk = snPreview ? squash(snLastArticle()).indexOf(snPreview) !== -1
                : (snSignature() !== prevSig && Date.now() - nameOkAt > 1500);
              if (contentOk) { ok = true; break; }
            }
            if (ok) await sleep(800); // slow-rendering replies (a 1 s pass once dropped a real decline)
          } catch (e) { ok = false; }
        }
        if (!ok) {
          meta.skipped++;
          if (meta.skippedNames.length < 30) meta.skippedNames.push(want);
          continue;
        }
        const conversationLink = rowLink || (() => { const m = location.href.match(/\/sales\/inbox\/([^/?]+)/); return m ? "https://www.linkedin.com/sales/inbox/" + m[1] : null; })();
        const threadId = (conversationLink || "").split("/sales/inbox/")[1] || null;

        let profileUrl = null;
        const leadA = Array.from(document.querySelectorAll('a[href*="/sales/lead/"]')).find((x) => !x.closest(".conversation-list-item"));
        if (leadA) {
          const lp = leadA.getAttribute("href").split("?")[0].split(",")[0];
          profileUrl = lp.startsWith("http") ? lp : ("https://www.linkedin.com" + lp);
        }

        const blocks = Array.from(document.querySelectorAll("article"))
          .map((a) => a.innerText.trim().replace(/\s+/g, " "))
          .filter((t) => !/Message thread list/i.test(t) && t.length > 2);
        const parsed = blocks.map((t) => ({ fromYou: /^(You|Vous)\b/.test(t), text: t }));
        const last = parsed[parsed.length - 1];
        const lastLeadObj = parsed.slice().reverse().find((p) => !p.fromYou);
        const lastFromYou = last ? last.fromYou : null;
        let lastLeadText = "";
        if (lastLeadObj) {
          lastLeadText = lastLeadObj.text
            .replace(/^[^]*?(AM|PM|\d{1,2}:\d{2})\s*/, "")
            .replace(/^(Accepted|Declined|A accepté|A refusé) (your|votre) InMail\s*/i, "")
            .trim();
        }

        const replied = !!lastLeadText;
        const decline = DECLINE_OR_DEFER.test(lastLeadText);
        const enthusiastic = /int[ée]ress|oui|call|discut|rendez|meeting|volontiers|avec plaisir/i.test(lastLeadText);
        const status = decline ? "Orange" : (!replied ? "Green" : (lastFromYou ? "Green" : "Red"));
        const interest = decline ? "Low" : (!replied ? "N/A" : (enthusiastic ? "High" : "Medium"));
        const ball = status === "Red" ? "your turn" : (status === "Green" ? "their turn" : "closed");

        if (conversationLink) seen.add(conversationLink);
        meta.verified++;
        conversations.push({
          name: snPaneName() || want,
          snippet: lastLeadText || "(no reply yet)",
          lastYouText: (last && last.fromYou) ? last.text.replace(/^(You|Vous)\s*[^]*?(AM|PM|\d{1,2}:\d{2})\s*/, "").slice(0, 200) : "",
          status,
          reason: decline ? "Decline / out-of-office / deferral" : (replied ? (lastFromYou ? "Lead replied — you answered" : "Lead replied") : "Awaiting their reply"),
          conversationLink,
          threadId,
          profileUrl,
          interest,
          fit: decline ? "Low" : "",
          ball,
          date: listTime,
          language: detectLang(lastLeadText || (last && last.text) || want),
          city: "",
          country: "",
          platform: "sales-navigator",
          source: "sales-navigator",
          lastSender: lastFromYou ? "you" : "them",
          verified: true,
          collectedAt: new Date().toISOString(),
        });

        chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", count: conversations.length, total: LIMIT, phase: "capturing-links" });
      }

      if (scrollC) scrollC.scrollTop = scrollC.scrollHeight;
      await sleep(1500);
    }

    meta.complete = conversations.length >= LIMIT || stagnant >= 6;
    console.log("[Pulse] Collected " + conversations.length + " Sales Navigator conversations (" + meta.skipped + " skipped)");
    return { conversations, meta };
  }

  // Quick scan — no scrolling, just visible items
  function quickScan() {
    if (isSalesNavigator) {
      const items = document.querySelectorAll('.conversation-list-item');
      const conversations = [];
      items.forEach((item) => {
        const data = extractSNConversation(item);
        if (data) conversations.push(data);
      });
      return conversations;
    } else {
      const items = document.querySelectorAll("li.msg-conversation-listitem");
      const conversations = [];
      items.forEach((item) => {
        const data = extractConversation(item);
        if (data) conversations.push(data);
      });
      return conversations;
    }
  }

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "START_COLLECTION") {
      if (isSalesNavigator) {
        collectAllSNConversations().then((r) => {
          sendResponse({ success: true, conversations: r.conversations, meta: r.meta });
        });
      } else {
        collectAllConversations().then((r) => {
          sendResponse({ success: true, conversations: r.conversations, meta: r.meta });
        });
      }
      return true; // Keep channel open for async response
    }

    if (message.type === "QUICK_SCAN") {
      // Fast scan without scrolling - just what's visible
      const conversations = quickScan();
      sendResponse({ success: true, conversations });
      return true;
    }
  });

  console.log(`[Pulse] LinkedIn Collector content script loaded (${isSalesNavigator ? 'Sales Navigator' : 'LinkedIn Messaging'} mode)`);
})();
