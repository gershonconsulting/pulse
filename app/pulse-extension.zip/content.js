// Pulse LinkedIn Collector - Content Script
// Runs on LinkedIn messaging pages and Sales Navigator inbox to extract conversation data

(function () {
  "use strict";

  const SCROLL_DELAY = 1500;
  const MAX_SCROLL_ATTEMPTS = 50;
  const CAMPAIGN_PATTERN = /\b(BD\d+)\b/i; // Matches campaign codes like BD18, BD20

  // Detect page type
  const isSalesNavigator = location.pathname.startsWith('/sales/inbox');

  // Classification rules
  function classify(conversation) {
    const { lastSender, snippet } = conversation;
    const lower = snippet.toLowerCase();

    // GREEN: You (Olivier) sent the last message
    if (lastSender === "you") {
      return { status: "Green", reason: "You sent the last message" };
    }

    // Check for ORANGE patterns (no action needed)
    const declinePatterns = [
      /non\s*(merci|pas)/i,
      /not\s*interested/i,
      /no\s*thank/i,
      /already\s*(have|present|exist)/i,
      /d[eé]j[aà]/i,
      /pas\s*(du\s*tout|besoin|int[eé]ress)/i,
      /belle\s*soir[eé]e/i,
      /bonne\s*(journ[eé]e|continuation)/i,
      /merci\s*(je\s*regarde|pour)/i,
      /i('|\s)ll\s*(look|check|get\s*back)/i,
      /we('|\s)re\s*(good|all\s*set|covered)/i,
      /no\s*need/i,
      /freelance.*seul/i,
    ];

    for (const pattern of declinePatterns) {
      if (pattern.test(lower)) {
        return { status: "Orange", reason: "Decline or acknowledgment detected" };
      }
    }

    // RED: Question, interest, action needed
    const redPatterns = [
      /\?/,
      /drop\s*(me|us)\s*(an?\s*)?email/i,
      /let('|\s)s\s*(connect|chat|talk|meet|schedule|arrange)/i,
      /interested/i,
      /i('|\s)d\s*(love|like)\s*to/i,
      /can\s*(we|you)/i,
      /would\s*(love|like|value)/i,
      /reach(ing)?\s*out/i,
      /open\s*to/i,
      /working\s*on\s*something/i,
      /your\s*perspective/i,
      /how\s*to/i,
      /tell\s*me\s*more/i,
      /send\s*(me|us)/i,
      /waiting/i,
      /follow\s*up/i,
      /thank\s*you\s*for\s*reach/i,
      /great\s*to\s*reconnect/i,
      /investor/i,
      /syndicate/i,
      /attachment/i,
    ];

    for (const pattern of redPatterns) {
      if (pattern.test(lower)) {
        return { status: "Red", reason: "Interest, question, or action needed" };
      }
    }

    // Default: if they sent last and no pattern matched, mark Red (safe side)
    if (lastSender !== "you") {
      return { status: "Red", reason: "They sent last - review needed" };
    }

    return { status: "Green", reason: "No action detected" };
  }

  // Extract data from a single LinkedIn Messaging conversation list item
  function extractConversation(item) {
    const lines = item.innerText.split("\n").filter((l) => l.trim());

    // Find name (skip status lines, timestamps, notifications)
    let name = "";
    for (const line of lines) {
      if (
        line.startsWith("Status is") ||
        line.match(/^\d+:\d+/) ||
        line.match(/^May|^Apr|^Mar|^Feb|^Jan|^Jun|^Jul|^Aug|^Sep|^Oct|^Nov|^Dec/) ||
        line.includes("new notification") ||
        line.includes("Press return") ||
        line.includes("Open the options") ||
        line.includes("Active conversation") ||
        line.includes("Star conversation") ||
        line.includes("Select conversation") ||
        line.includes("Received") ||
        line.includes("Sponsored") ||
        line.length <= 2
      ) {
        continue;
      }
      name = line.trim();
      break;
    }

    // Find snippet (message preview)
    let snippet = "";
    let lastSender = "them";
    for (const line of lines) {
      if (line.startsWith("You:")) {
        snippet = line.substring(4).trim();
        lastSender = "you";
        break;
      }
      const nameFirst = name.split(" ")[0];
      if (line.startsWith(nameFirst + ":")) {
        snippet = line.substring(nameFirst.length + 1).trim();
        lastSender = "them";
        break;
      }
    }

    // Find date
    let date = "";
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.match(/^\d+:\d+\s*(AM|PM)$/i)) {
        date = trimmed;
        break;
      }
      if (trimmed.match(/^(May|Apr|Mar|Feb|Jan|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d+$/)) {
        date = trimmed;
        break;
      }
    }

    // Unread count
    let unread = 0;
    const unreadEl = item.querySelector('[class*="unread-count"]');
    if (unreadEl) {
      unread = parseInt(unreadEl.innerText) || 0;
    }

    // LinkedIn profile URL
    let profileUrl = "";
    const profileLink = item.querySelector('a[href*="/in/"]');
    if (profileLink) {
      profileUrl = profileLink.href;
    }

    // Thread ID from conversation link — try multiple strategies
    let threadId = "";
    let conversationLink = "";

    // Strategy 1: The main conversation link element (most reliable)
    const mainLink = item.querySelector('a.msg-conversation-listitem__link') ||
                     item.querySelector('a[href*="/messaging/thread/"]') ||
                     item.querySelector('a[data-control-name="view_message"]');
    if (mainLink) {
      const href = mainLink.getAttribute("href") || "";
      const threadMatch = href.match(/\/messaging\/thread\/([^/?]+)/);
      if (threadMatch) {
        threadId = threadMatch[1];
        conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
      }
    }

    // Strategy 2: Any <a> inside the list item with a thread path
    if (!threadId) {
      const allLinks = item.querySelectorAll('a[href]');
      for (const link of allLinks) {
        const href = link.getAttribute("href") || "";
        const threadMatch = href.match(/\/messaging\/thread\/([^/?]+)/);
        if (threadMatch) {
          threadId = threadMatch[1];
          conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
          break;
        }
      }
    }

    // Strategy 3: data attributes on the item or its children
    if (!threadId) {
      const dataId = item.getAttribute("data-thread-id") ||
                     item.querySelector('[data-thread-id]')?.getAttribute("data-thread-id") ||
                     item.getAttribute("data-thread-urn") ||
                     item.querySelector('[data-thread-urn]')?.getAttribute("data-thread-urn") || "";
      if (dataId) {
        threadId = dataId.replace(/^urn:li:messagingThread:/, '');
        conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
      }
    }

    // Strategy 4: Extract from the item's id attribute (LinkedIn uses URN-based IDs)
    if (!threadId) {
      const itemId = item.getAttribute("id") || "";
      const idMatch = itemId.match(/thread[_-]?(.+)/i);
      if (idMatch) {
        threadId = idMatch[1];
        conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
      }
    }

    // Strategy 5: Click the item to trigger navigation, read the URL from the panel
    // (done passively — if conversation is already selected, grab from current URL)
    if (!threadId && window.location.href.includes('/messaging/thread/')) {
      // Check if this conversation is the currently active one
      const isActive = item.classList.contains('active') ||
                       item.querySelector('.msg-conversation-listitem__link--active');
      if (isActive) {
        const urlMatch = window.location.href.match(/\/messaging\/thread\/([^/?]+)/);
        if (urlMatch) {
          threadId = urlMatch[1];
          conversationLink = "https://www.linkedin.com/messaging/thread/" + threadId + "/";
        }
      }
    }

    // Last resort: use searchString (unreliable but better than nothing)
    if (!conversationLink && name) {
      conversationLink = "https://www.linkedin.com/messaging/?searchString=" + encodeURIComponent(name);
    }

    // Extract campaign code from snippet or full text
    let campaign = null;
    const allText = lines.join(" ");
    const campMatch = allText.match(CAMPAIGN_PATTERN);
    if (campMatch) {
      campaign = campMatch[1].toUpperCase();
    }
    // Also check snippet specifically
    if (!campaign && snippet) {
      const snippetMatch = snippet.match(CAMPAIGN_PATTERN);
      if (snippetMatch) campaign = snippetMatch[1].toUpperCase();
    }

    if (!name || name.includes("Sponsored")) return null;

    const conv = { name, snippet, lastSender, date, unread, profileUrl };
    const classification = classify(conv);

    return {
      ...conv,
      status: classification.status,
      reason: classification.reason,
      threadId,
      conversationLink,
      campaign,
      source: "linkedin-messaging",
      collectedAt: new Date().toISOString(),
    };
  }

  // Extract data from a single Sales Navigator inbox conversation list item
  function extractSNConversation(item) {
    const lines = item.innerText.split("\n").filter((l) => l.trim());

    // Sales Navigator structure: [Name, Snippet, Date]
    let name = "";
    let snippet = "";
    let date = "";

    if (lines.length >= 1) {
      name = lines[0].trim();
    }
    if (lines.length >= 2) {
      snippet = lines[1].trim();
    }
    if (lines.length >= 3) {
      date = lines[2].trim();
    }

    if (!name) return null;

    // Determine lastSender:
    // In SN there's no "You:" prefix. Detect if you sent last by checking
    // if snippet starts with greeting patterns (= you initiated/replied last)
    let lastSender = "them";
    const youSentPatterns = [
      /^Bonjour\s/i,
      /^Hi\s/i,
      /^Hello\s/i,
      /^Hey\s/i,
      /^Dear\s/i,
      /^Cher\s/i,
      /^Ch[eè]re\s/i,
      /^Bonsoir\s/i,
    ];
    for (const pattern of youSentPatterns) {
      if (pattern.test(snippet)) {
        lastSender = "you";
        break;
      }
    }

    // Thread ID from data attribute
    let threadId = "";
    const dataAttr = item.getAttribute("data-x-conversation-list-item") || "";
    if (dataAttr) {
      threadId = dataAttr;
    }

    // Conversation link from the item's link element
    let conversationLink = "";
    const linkEl = item.querySelector('.conversation-list-item__link');
    if (linkEl) {
      const href = linkEl.getAttribute("href") || "";
      const snMatch = href.match(/\/sales\/inbox\/([^/?]+)/);
      if (snMatch) {
        threadId = threadId || snMatch[1];
        conversationLink = "https://www.linkedin.com/sales/inbox/" + (threadId || snMatch[1]);
      }
    }
    if (!conversationLink && threadId) {
      conversationLink = "https://www.linkedin.com/sales/inbox/" + threadId;
    }

    // No profile links available in SN list items
    const profileUrl = "";

    // No unread badge elements found in SN
    const unread = 0;

    // Extract campaign code from snippet or full text
    let campaign = null;
    const allText = lines.join(" ");
    const campMatch = allText.match(CAMPAIGN_PATTERN);
    if (campMatch) {
      campaign = campMatch[1].toUpperCase();
    }
    if (!campaign && snippet) {
      const snippetMatch = snippet.match(CAMPAIGN_PATTERN);
      if (snippetMatch) campaign = snippetMatch[1].toUpperCase();
    }

    const conv = { name, snippet, lastSender, date, unread, profileUrl };
    const classification = classify(conv);

    return {
      ...conv,
      status: classification.status,
      reason: classification.reason,
      threadId,
      conversationLink,
      campaign,
      source: "sales-navigator",
      collectedAt: new Date().toISOString(),
    };
  }

  // Scroll the LinkedIn Messaging conversation list to load all items
  async function scrollConversationList() {
    const listEl = document.querySelector(".msg-conversations-container__conversations-list");
    if (!listEl) {
      console.log("[Pulse] Conversation list not found");
      return;
    }

    let previousCount = 0;
    let attempts = 0;

    while (attempts < MAX_SCROLL_ATTEMPTS) {
      const items = document.querySelectorAll("li.msg-conversation-listitem");
      const currentCount = items.length;

      if (currentCount === previousCount && attempts > 2) {
        // Try clicking "Load more" button
        const loadMore = document.querySelector(
          'button[aria-label*="Load more"], button:has(> span:contains("Load more"))'
        );
        if (loadMore) {
          loadMore.click();
          await sleep(2000);
        } else {
          // Also try finding by text content
          const buttons = document.querySelectorAll("button");
          let found = false;
          for (const btn of buttons) {
            if (btn.innerText.includes("Load more conversations")) {
              btn.click();
              found = true;
              await sleep(2000);
              break;
            }
          }
          if (!found) {
            console.log(`[Pulse] No more conversations to load. Total: ${currentCount}`);
            break;
          }
        }
      }

      previousCount = currentCount;

      // Scroll the conversation list container
      const scrollContainer =
        listEl.closest(".msg-conversations-container__conversations-list") ||
        listEl.parentElement;
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
      // Also scroll the list itself
      listEl.scrollTop = listEl.scrollHeight;

      attempts++;
      await sleep(SCROLL_DELAY);

      // Update progress via message to popup
      chrome.runtime.sendMessage({
        type: "SCAN_PROGRESS",
        count: currentCount,
        attempt: attempts,
      });
    }
  }

  // Scroll the Sales Navigator inbox list to load all items
  async function scrollSNConversationList() {
    // Find the scrollable container for SN inbox
    const listItems = document.querySelectorAll('.conversation-list-item');
    if (!listItems.length) {
      console.log("[Pulse] Sales Navigator conversation list not found");
      return;
    }

    // Find the scroll container (parent of the list items)
    const scrollContainer = listItems[0].closest('[class*="conversation-list"]') ||
                            listItems[0].parentElement;
    if (!scrollContainer) {
      console.log("[Pulse] Sales Navigator scroll container not found");
      return;
    }

    let previousCount = 0;
    let attempts = 0;

    while (attempts < MAX_SCROLL_ATTEMPTS) {
      const items = document.querySelectorAll('.conversation-list-item');
      const currentCount = items.length;

      if (currentCount === previousCount && attempts > 2) {
        console.log(`[Pulse] No more SN conversations to load. Total: ${currentCount}`);
        break;
      }

      previousCount = currentCount;

      // Scroll the container
      scrollContainer.scrollTop = scrollContainer.scrollHeight;

      attempts++;
      await sleep(SCROLL_DELAY);

      // Update progress via message to popup
      chrome.runtime.sendMessage({
        type: "SCAN_PROGRESS",
        count: currentCount,
        attempt: attempts,
      });
    }
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Language detection (lightweight heuristic; user can correct on the dashboard).
  function detectLang(t) {
    t = (t || "").toLowerCase();
    const fr = (t.match(/\b(bonjour|merci|vous|votre|nous|je|suis|être|avec|pour|bonne|journée|entreprise|société|très|aussi|besoin|intéress|rendez|discuter|salut|cordialement)\b/g) || []).length;
    const en = (t.match(/\b(hi|hello|the|you|your|we|our|thanks|thank|would|could|please|team|company|interested|meeting|reach|best|regards)\b/g) || []).length;
    if (fr > en && fr >= 2) return "French";
    if (en >= 2) return "English";
    return fr > en ? "French" : "English";
  }

  // A reply that means "no action needed now" — an explicit decline, OR an
  // out-of-office / deferral ("taking time off", "get back to you later").
  const DECLINE_OR_DEFER = /pas int[ée]ress|aucun besoin|ne m.int[ée]resse|not interested|no need|no thank|d[ée]clin|unsubscribe|time off|out of office|on vacation|on holiday|on leave|\bo\.?o\.?o\b|limited (internet|connectivity|access)|get back to you|at a later time|circle back|reconnect later|currently (traveling|travelling|away)|en cong[ée]|en vacances|absent|je reviens vers vous/i;

  // Main collection function — LinkedIn Messaging (up to LIMIT most recent).
  // Scrolls the list to load more, opens each conversation to capture the EXACT
  // thread URL + partner profile URL, and reads the real message list for the
  // last message, sender, and language. Processed rows are marked so the
  // scroll-and-collect loop never re-opens the same one; dedupe by threadId.
  async function collectAllConversations() {
    const LIMIT = 100;
    console.log("[Pulse] Collecting up to " + LIMIT + " recent LinkedIn conversations...");

    // Wait until the conversation list actually renders (up to ~18s).
    let waited = 0;
    while (document.querySelectorAll("li.msg-conversation-listitem").length === 0 && waited < 36) {
      await sleep(500);
      waited++;
    }
    await sleep(1000);

    const ownerName = (((document.querySelector(".global-nav__me-photo") || {}).alt) || "Olivier Attia").replace(/\s+/g, " ").trim();
    const listEl = document.querySelector(".msg-conversations-container__conversations-list");

    const conversations = [];
    const seenThreads = new Set();
    let stagnant = 0;

    while (conversations.length < LIMIT && stagnant < 6) {
      const fresh = Array.from(document.querySelectorAll("li.msg-conversation-listitem:not([data-pulse-done])"));
      if (fresh.length === 0) {
        if (listEl) listEl.scrollTop = listEl.scrollHeight;
        await sleep(1500);
        stagnant++;
        continue;
      }
      stagnant = 0;

      for (const item of fresh) {
        if (conversations.length >= LIMIT) break;
        item.setAttribute("data-pulse-done", "1");
        const data = extractConversation(item) || {};
        const nameEl = item.querySelector(".msg-conversation-listitem__participant-names, h3");
        if (nameEl && nameEl.innerText.trim()) data.name = nameEl.innerText.trim();
        const timeEl = item.querySelector("time, .msg-conversation-listitem__time-stamp");
        if (timeEl && timeEl.innerText.trim()) data.date = timeEl.innerText.trim();
        if (!data.name) continue;

        try {
          const clickable =
            item.querySelector(".msg-conversation-listitem__link") ||
            item.querySelector('[role="link"]') ||
            item;
          clickable.scrollIntoView({ block: "center" });
          await sleep(200);
          clickable.click();
          await sleep(1600);

          const tMatch = window.location.href.match(/\/messaging\/thread\/([^/?]+)/);
          if (tMatch) {
            data.threadId = tMatch[1];
            data.conversationLink = "https://www.linkedin.com/messaging/thread/" + tMatch[1] + "/";
          }
          if (data.threadId && seenThreads.has(data.threadId)) continue;

          const primary = document.querySelector(".msg-thread__link-to-profile");
          const primaryHref = primary ? primary.getAttribute("href").split("?")[0] : null;
          const allIn = Array.from(
            document.querySelectorAll(".msg-thread a[href*='/in/'], .msg-title-bar a[href*='/in/']")
          ).map((a) => a.getAttribute("href")).filter(Boolean).map((h) => h.split("?")[0]);
          const OWNER = /olivierattia/i;
          const vanityOther = allIn.find((h) => !/\/in\/ACoAA/i.test(h) && !OWNER.test(h));
          const chosen = primaryHref || vanityOther || allIn.find((h) => !OWNER.test(h));
          if (chosen) data.profileUrl = chosen.startsWith("http") ? chosen : "https://www.linkedin.com" + chosen;

          const evs = Array.from(document.querySelectorAll(".msg-s-event-listitem"));
          const allText = evs.map((e) => (e.querySelector(".msg-s-event-listitem__body") || {}).innerText || "").join(" ");
          let lastBody = "";
          for (let k = evs.length - 1; k >= 0; k--) {
            const b = (evs[k].querySelector(".msg-s-event-listitem__body") || {}).innerText;
            if (b && b.trim()) { lastBody = b.trim(); break; }
          }
          let lastAuthor = null;
          for (let k = evs.length - 1; k >= 0; k--) {
            const n = evs[k].querySelector('[class*="__name"]');
            if (n && n.innerText.trim()) { lastAuthor = n.innerText.trim().replace(/\s+/g, " "); break; }
          }
          if (lastBody) data.snippet = lastBody.slice(0, 300);
          data.lastSender = (lastAuthor && lastAuthor === ownerName) ? "you" : "them";
          data.language = detectLang(allText || lastBody);

          const low = (lastBody || "").toLowerCase();
          if (data.lastSender === "you") {
            data.status = "Green"; data.reason = "You sent the last message"; data.ball = "their turn";
          } else if (DECLINE_OR_DEFER.test(low)) {
            data.status = "Orange"; data.reason = "Decline / out-of-office / deferral"; data.ball = "closed";
          } else {
            data.status = "Red"; data.reason = "They replied — your turn"; data.ball = "your turn";
          }
        } catch (e) {
          console.log("[Pulse] capture failed for " + (data.name || "?") + ": " + e.message);
        }

        if (data.threadId) seenThreads.add(data.threadId);
        data.country = data.country || "";
        data.city = data.city || "";
        data.platform = "linkedin";
        if (data.date && !data.timestamp) data.timestamp = data.date;
        conversations.push(data);

        chrome.runtime.sendMessage({ type: "SCAN_PROGRESS", count: conversations.length, total: LIMIT, phase: "capturing-links" });
      }

      // Load more, then loop.
      if (listEl) listEl.scrollTop = listEl.scrollHeight;
      await sleep(1200);
    }

    console.log("[Pulse] Collected " + conversations.length + " LinkedIn conversations");
    return conversations;
  }

  // Main collection function — Sales Navigator
  async function collectAllSNConversations() {
    console.log("[Pulse] Starting Sales Navigator conversation collection...");

    const LIMIT = 100;
    // Wait for the SN inbox list to render.
    let wSN = 0;
    while (document.querySelectorAll('.conversation-list-item').length === 0 && wSN < 36) { await sleep(500); wSN++; }
    await sleep(1000);

    const anyItem = document.querySelector('.conversation-list-item');
    const scrollC = anyItem ? (anyItem.closest('[class*="conversation-list"]') || anyItem.parentElement) : null;

    const conversations = [];
    const seen = new Set();
    let stagnant = 0;

    while (conversations.length < LIMIT && stagnant < 6) {
      const fresh = Array.from(document.querySelectorAll('.conversation-list-item:not([data-pulse-done])'));
      if (fresh.length === 0) {
        if (scrollC) scrollC.scrollTop = scrollC.scrollHeight;
        await sleep(1500);
        stagnant++;
        continue;
      }
      stagnant = 0;

      for (const item of fresh) {
        if (conversations.length >= LIMIT) break;
        item.setAttribute('data-pulse-done', '1');
        const lines0 = item.innerText.trim().split('\n').map((s) => s.trim()).filter(Boolean);
        // Clean the name: drop presence noise like "was last active 2 hours ago".
        let name = (lines0[0] || '').trim()
          .replace(/\s+was (last )?active.*$/i, '')
          .replace(/\s+·\s.*$/, '')
          .trim();
        if (!name) continue;
        const listTime = lines0.find((l) => /\d{1,2}:\d{2}\s*(AM|PM)/i.test(l) || /^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)$/i.test(l) || /^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\b/i.test(l)) || '';

        const tA = item.querySelector('a[href*="/sales/inbox/"]');
        let conversationLink = tA ? ('https://www.linkedin.com' + tA.getAttribute('href').split('?')[0]) : null;
        let profileUrl = null, lastLeadText = '', lastFromYou = null;

        try {
          (tA || item).click();
          await sleep(2500); // SN lead card + messages render slowly
          if (!conversationLink) {
            const m = location.href.match(/\/sales\/inbox\/([^/?]+)/);
            if (m) conversationLink = 'https://www.linkedin.com/sales/inbox/' + m[1];
          }
          if (seen.has(conversationLink || name)) continue;

          // Lead profile link. The href carries ",NAME_SEARCH,xxxx" tracking after
          // the id — strip it to the clean /sales/lead/<id> form.
          const leadA = document.querySelector('a[href*="/sales/lead/"]');
          if (leadA) {
            const lp = leadA.getAttribute('href').split('?')[0].split(',')[0];
            profileUrl = lp.startsWith('http') ? lp : ('https://www.linkedin.com' + lp);
          }

          // Messages render as <article>; the conversation LIST is also an article,
          // so drop the one containing the list search text.
          const blocks = Array.from(document.querySelectorAll('article'))
            .map((a) => a.innerText.trim().replace(/\s+/g, ' '))
            .filter((t) => !/Message thread list/i.test(t) && t.length > 2);
          const parsed = blocks.map((t) => ({ fromYou: /^You\b/.test(t), text: t }));
          const last = parsed[parsed.length - 1];
          const lastLeadObj = parsed.slice().reverse().find((p) => !p.fromYou);
          lastFromYou = last ? last.fromYou : null;
          if (lastLeadObj) {
            lastLeadText = lastLeadObj.text
              .replace(/^[^]*?(AM|PM)\s*/, '')
              .replace(/^(Accepted|Declined) your InMail\s*/i, '')
              .trim();
          }
        } catch (e) {
          console.log("[Pulse] SN capture failed for " + name + ": " + e.message);
        }

        const replied = !!lastLeadText;
        const decline = DECLINE_OR_DEFER.test(lastLeadText);
        const enthusiastic = /int[ée]ress|oui|call|discut|rendez|meeting|volontiers|avec plaisir/i.test(lastLeadText);
        const status = decline ? 'Orange' : (!replied ? 'Green' : (lastFromYou ? 'Green' : 'Red'));
        const interest = decline ? 'Low' : (!replied ? 'N/A' : (enthusiastic ? 'High' : 'Medium'));
        const ball = status === 'Red' ? 'your turn' : (status === 'Green' ? 'their turn' : 'closed');
        const language = detectLang(lastLeadText || name);

        seen.add(conversationLink || name);
        conversations.push({
          name,
          snippet: lastLeadText || '(no reply yet)',
          status,
          reason: decline ? 'Decline / out-of-office / deferral' : (replied ? 'Lead replied' : 'Awaiting their reply'),
          conversationLink,
          profileUrl,
          interest,
          fit: decline ? 'Low' : '',
          ball,
          date: listTime,
          language,
          city: '',
          country: '',
          platform: 'sales-navigator',
          source: 'sales-navigator',
          lastSender: lastFromYou ? 'you' : 'them',
          collectedAt: new Date().toISOString(),
        });

        chrome.runtime.sendMessage({ type: 'SCAN_PROGRESS', count: conversations.length, total: LIMIT, phase: 'capturing-links' });
      }

      if (scrollC) scrollC.scrollTop = scrollC.scrollHeight;
      await sleep(1200);
    }

    console.log('[Pulse] Collected ' + conversations.length + ' Sales Navigator conversations');
    return conversations;
  }

  // Quick scan — no scrolling, just visible items
  function quickScan() {
    if (isSalesNavigator) {
      const items = document.querySelectorAll('.conversation-list-item');
      const conversations = [];
      items.forEach((item) => {
        const data = extractSNConversation(item);
        if (data) conversations.push(data);
      });
      return conversations;
    } else {
      const items = document.querySelectorAll("li.msg-conversation-listitem");
      const conversations = [];
      items.forEach((item) => {
        const data = extractConversation(item);
        if (data) conversations.push(data);
      });
      return conversations;
    }
  }

  // Listen for messages from popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "START_COLLECTION") {
      if (isSalesNavigator) {
        collectAllSNConversations().then((conversations) => {
          sendResponse({ success: true, conversations });
        });
      } else {
        collectAllConversations().then((conversations) => {
          sendResponse({ success: true, conversations });
        });
      }
      return true; // Keep channel open for async response
    }

    if (message.type === "QUICK_SCAN") {
      // Fast scan without scrolling - just what's visible
      const conversations = quickScan();
      sendResponse({ success: true, conversations });
      return true;
    }
  });

  console.log(`[Pulse] LinkedIn Collector content script loaded (${isSalesNavigator ? 'Sales Navigator' : 'LinkedIn Messaging'} mode)`);
})();
